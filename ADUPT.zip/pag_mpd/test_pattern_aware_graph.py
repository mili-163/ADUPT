#!/usr/bin/env python3
"""
Test script for Pattern-Aware Graph module
"""

import torch
import torch.nn as nn
import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_statistical_embedding():
    """Test Statistical Embedding module"""
    print("Testing Statistical Embedding...")
    
    try:
        from pattern_aware_graph.statistical_embedding import StatisticalEmbedding
        
        # Create test configuration
        config = {
            "hidden_size": 768,
            "num_modalities": 2,
            "statistical_embed_dim": 128,
            "drop_rate": 0.1
        }
        
        # Create module
        stat_embed = StatisticalEmbedding(config)
        
        # Create test data
        batch_size = 4
        hidden_size = 768
        num_modalities = 2
        
        # Test modality embeddings
        modality_embeddings = {
            "text": torch.randn(batch_size, hidden_size),
            "image": torch.randn(batch_size, hidden_size)
        }
        
        # Test missing mask (some samples missing text, some missing image)
        missing_mask = torch.tensor([
            [1, 1],  # Complete
            [1, 0],  # Missing image
            [0, 1],  # Missing text
            [0, 0]   # Missing both
        ])
        
        # Forward pass
        output = stat_embed(modality_embeddings, missing_mask)
        
        print(f"✓ Statistical embedding output shape: {output.shape}")
        print(f"✓ Expected shape: ({batch_size}, {config['statistical_embed_dim']})")
        
        assert output.shape == (batch_size, config['statistical_embed_dim']), "Output shape mismatch"
        
        # Test missing pattern stats
        stats = stat_embed.compute_missing_pattern_stats(missing_mask)
        print(f"✓ Missing pattern stats computed successfully")
        print(f"  - Mean missing: {stats['mean_missing']}")
        print(f"  - Var missing: {stats['var_missing']}")
        print(f"  - Num observed: {stats['num_observed']}")
        
        print("✓ Statistical Embedding test passed!\n")
        return True
        
    except Exception as e:
        print(f" Statistical Embedding test failed: {e}")
        return False

def test_cross_modal_dependencies():
    """Test Cross-Modal Dependencies module"""
    print("Testing Cross-Modal Dependencies...")
    
    try:
        from pattern_aware_graph.cross_modal_dependencies import CrossModalDependencies
        
        # Create test configuration
        config = {
            "num_modalities": 2,
            "use_prior_knowledge": True,
            "symmetric_adjacency": False
        }
        
        # Create module
        cross_modal = CrossModalDependencies(config)
        
        # Create test data
        batch_size = 4
        num_modalities = 2
        
        # Test missing mask
        missing_mask = torch.tensor([
            [1, 1],  # Complete
            [1, 0],  # Missing image
            [0, 1],  # Missing text
            [0, 0]   # Missing both
        ])
        
        # Forward pass
        output = cross_modal(missing_mask)
        
        print(f"✓ Cross-modal dependencies output keys: {list(output.keys())}")
        
        # Check output shapes
        adj_matrix = output['adjacency_matrix']
        norm_adj = output['normalized_adjacency']
        degree_matrix = output['degree_matrix']
        influence_weights = output['influence_weights']
        
        print(f"✓ Adjacency matrix shape: {adj_matrix.shape}")
        print(f"✓ Normalized adjacency shape: {norm_adj.shape}")
        print(f"✓ Degree matrix shape: {degree_matrix.shape}")
        print(f"✓ Influence weights shape: {influence_weights.shape}")
        
        # Test graph info
        graph_info = cross_modal.get_graph_info()
        print(f"✓ Graph info: {graph_info}")
        
        print("✓ Cross-Modal Dependencies test passed!\n")
        return True
        
    except Exception as e:
        print(f" Cross-Modal Dependencies test failed: {e}")
        return False

def test_modality_embeddings():
    """Test Modality Embeddings module"""
    print("Testing Modality Embeddings...")
    
    try:
        from pattern_aware_graph.modality_embeddings import ModalityEmbeddings
        
        # Create test configuration
        config = {
            "hidden_size": 768,
            "num_modalities": 2,
            "use_gating": True
        }
        
        # Create module
        modality_emb = ModalityEmbeddings(config)
        
        # Create test data
        batch_size = 4
        hidden_size = 768
        num_modalities = 2
        
        # Test modality embeddings
        modality_embeddings = {
            "text": torch.randn(batch_size, hidden_size),
            "image": torch.randn(batch_size, hidden_size)
        }
        
        # Test missing mask
        missing_mask = torch.tensor([
            [1, 1],  # Complete
            [1, 0],  # Missing image
            [0, 1],  # Missing text
            [0, 0]   # Missing both
        ])
        
        # Create normalized adjacency matrix
        normalized_adjacency = torch.tensor([
            [0.0, 0.5],
            [0.5, 0.0]
        ])
        
        # Forward pass
        output = modality_emb(modality_embeddings, missing_mask, normalized_adjacency)
        
        print(f"✓ Modality embeddings output keys: {list(output.keys())}")
        
        # Check output shapes
        for name, embedding in output.items():
            print(f" {name} embedding shape: {embedding.shape}")
            assert embedding.shape == (batch_size, hidden_size), f"Shape mismatch for {name}"
        
        # Test gating analysis
        gating_analysis = modality_emb.analyze_gating_behavior(missing_mask)
        print(f" Gating analysis keys: {list(gating_analysis.keys())}")
        
        print(" Modality Embeddings test passed!\n")
        return True
        
    except Exception as e:
        print(f" Modality Embeddings test failed: {e}")
        return False

def test_pattern_aware_graph_encoder():
    """Test Pattern-Aware Graph Encoder"""
    print("Testing Pattern-Aware Graph Encoder...")
    
    try:
        from pattern_aware_graph.graph_encoder import PatternAwareGraphEncoder
        
        # Create test configuration
        config = {
            "hidden_size": 768,
            "num_modalities": 2,
            "modality_names": ["text", "image"],
            "statistical_embed_dim": 128,
            "drop_rate": 0.1,
            "use_final_projection": False
        }
        
        # Create module
        graph_encoder = PatternAwareGraphEncoder(config)
        
        # Create test data
        batch_size = 4
        hidden_size = 768
        
        # Test embeddings
        text_embeds = torch.randn(batch_size, hidden_size)
        image_embeds = torch.randn(batch_size, hidden_size)
        
        # Test missing mask
        missing_mask = torch.tensor([
            [1, 1],  # Complete
            [1, 0],  # Missing image
            [0, 1],  # Missing text
            [0, 0]   # Missing both
        ])
        
        # Forward pass
        routing_context = graph_encoder(text_embeds, image_embeds, missing_mask)
        
        print(f"Routing context shape: {routing_context.shape}")
        expected_dim = graph_encoder.get_routing_context_dim()
        print(f"Expected routing context dimension: {expected_dim}")
        
        assert routing_context.shape == (batch_size, expected_dim), "Routing context shape mismatch"
        
        # Test analysis functions
        graph_info = graph_encoder.get_graph_info()
        print(f"Graph info: {graph_info}")
        
        missing_analysis = graph_encoder.analyze_missing_patterns(missing_mask)
        print(f"Missing pattern analysis keys: {list(missing_analysis.keys())}")
        
        print(" Pattern-Aware Graph Encoder test passed!\n")
        return True
        
    except Exception as e:
        print(f" Pattern-Aware Graph Encoder test failed: {e}")
        return False

def test_integration():
    """Test integration with main model"""
    print("Testing integration with main model...")
    
    try:
        # Defer heavy imports to handle missing optional deps gracefully
        try:
            import pytorch_lightning as _pl  # noqa: F401
            from transformers.models.bert.modeling_bert import BertConfig as _BC  # noqa: F401
        except Exception as dep_err:
            print(f"⚠️ Skip integration test due to optional deps missing: {dep_err}")
            return True

        from core.pag_mpd_model import PAGMPDModel
        
        # Create test configuration
        config = {
            "vocab_size": 30522,
            "hidden_size": 768,
            "num_layers": 12,
            "num_heads": 12,
            "mlp_ratio": 4,
            "max_text_len": 40,
            "drop_rate": 0.1,
            "vit": "vit_base_patch32_224",
            "load_path": "",
            "num_modalities": 2,
            "modality_names": ["text", "image"],
            "statistical_embed_dim": 128,
            "use_final_projection": False,
            "loss_names": {
                "hatememes": 1,
                "food101": 0,
                "mmimdb": 0
            },
            "hatememes_class_num": 2,
            "food101_class_num": 101,
            "mmimdb_class_num": 23
        }
        
        # Create model
        model = PAGMPDModel(config)
        
        print(f"Model created successfully")
        print(f"Pattern-aware graph encoder: {type(model.pattern_aware_graph).__name__}")
        
        # Test that the model has the expected components
        assert hasattr(model, 'pattern_aware_graph'), "Model missing pattern_aware_graph"
        assert hasattr(model, 'text_embeddings'), "Model missing text_embeddings"
        assert hasattr(model, 'transformer'), "Model missing transformer"
        
        print("Integration test passed!\n")
        return True
        
    except Exception as e:
        print(f"Integration test failed: {e}")
        return False

if __name__ == "__main__":
    print("Testing Pattern-Aware Graph Module")
    print("=" * 50)
    
    # Run tests
    tests = [
        test_statistical_embedding,
        test_cross_modal_dependencies,
        test_modality_embeddings,
        test_pattern_aware_graph_encoder,
        test_integration
    ]
    
    all_passed = True
    for test in tests:
        if not test():
            all_passed = False
    
    if all_passed:
        print("All Pattern-Aware Graph tests passed!")
        print("The first module is working correctly.")
    else:
        print("Some tests failed. Please check the errors above.")
        sys.exit(1)
