"""
缺失感知蒸馏模型配置文件

这个文件包含了所有配置参数
"""

import torch

# 基础模型配置
BASE_CONFIG = {
    # 模型架构
    "hidden_size": 768,
    "num_layers": 12,
    "num_heads": 12,
    "mlp_ratio": 4,
    "drop_rate": 0.1,
    
    # 任务配置
    "num_classes": 2,
    "num_modalities": 2,  # 文本 + 图像
    "vocab_size": 30522,
    "max_text_len": 40,
    "max_image_len": 197,
    
    # 提示配置
    "prompt_length": 4,
    "num_prompt_layers": 4,
    
    # 训练配置
    "batch_size": 32,
    "learning_rate": 1e-4,
    "weight_decay": 0.01,
    "num_epochs_teacher": 50,
    "num_epochs_inference": 100,
    
    # 设备配置
    "device": "cuda" if torch.cuda.is_available() else "cpu",
    "num_workers": 4,
    
    # 数据配置
    "train_split": 0.8,
    "val_split": 0.1,
    "test_split": 0.1,
}

# 缺失感知模态级提示配置
MODALITY_PROMPTS_CONFIG = {
    "hidden_size": 768,
    "num_modalities": 2,
    "prompt_length": 4,
    "num_layers": 4,
}

# 双实例级提示配置
DUAL_PROMPTS_CONFIG = {
    "hidden_size": 768,
    "num_modalities": 2,
    "prompt_length": 4,
    "num_layers": 4,
}

# 分层蒸馏配置
DISTILLATION_CONFIG = {
    "hidden_size": 768,
    "selected_layers": [4, 8, 12],  # 选择进行特征对齐的层
    "distillation_temperature": 4.0,
    "lambda_feat": 1.0,  # 特征对齐损失权重
    "lambda_pred": 1.0,  # 预测对齐损失权重
}

# 硬负样本对比配置
CONTRASTIVE_CONFIG = {
    "hidden_size": 768,
    "num_classes": 2,
    "contrastive_temperature": 0.07,
    "top_k_negatives": 5,
    "lambda_hno": 0.5,  # 硬负样本对比损失权重
}

# 校准提示适应配置
CPA_CONFIG = {
    "hidden_size": 768,
    "adaptation_lr": 0.01,
    "entropy_weight": 1.0,
    "alignment_weight": 0.1,
    "num_augmentations": 3,
}

# 损失权重配置
LOSS_WEIGHTS = {
    "lambda_cls": 1.0,      # 分类损失权重
    "lambda_abs": 0.1,      # 掩码重构损失权重
    "lambda_feat": 1.0,     # 特征蒸馏损失权重
    "lambda_pred": 1.0,     # 预测蒸馏损失权重
    "lambda_hno": 0.5,      # 硬负样本对比损失权重
}

# 数据集特定配置
DATASET_CONFIGS = {
    "hatememes": {
        "num_classes": 2,
        "class_names": ["normal", "hateful"],
        "image_size": (224, 224),
        "text_max_length": 40,
    },
    "food101": {
        "num_classes": 101,
        "class_names": None,  # 将动态加载
        "image_size": (224, 224),
        "text_max_length": 40,
    },
    "mmimdb": {
        "num_classes": 23,
        "class_names": None,  # 将动态加载
        "image_size": (224, 224),
        "text_max_length": 40,
    }
}

# 完整配置
def get_config(dataset_name: str = "hatememes") -> dict:
    """
    获取完整配置
    
    Args:
        dataset_name: 数据集名称
        
    Returns:
        dict: 完整配置
    """
    config = BASE_CONFIG.copy()
    
    # 添加数据集特定配置
    if dataset_name in DATASET_CONFIGS:
        config.update(DATASET_CONFIGS[dataset_name])
    
    # 添加组件配置
    config.update({
        "modality_prompts_config": MODALITY_PROMPTS_CONFIG,
        "dual_prompts_config": DUAL_PROMPTS_CONFIG,
        "distillation_config": DISTILLATION_CONFIG,
        "contrastive_config": CONTRASTIVE_CONFIG,
        "cpa_config": CPA_CONFIG,
        "loss_weights": LOSS_WEIGHTS,
    })
    
    return config

# 训练配置
TRAINING_CONFIG = {
    "teacher_training": {
        "optimizer": "AdamW",
        "learning_rate": 1e-4,
        "weight_decay": 0.01,
        "scheduler": "CosineAnnealingLR",
        "num_epochs": 50,
        "early_stopping_patience": 10,
    },
    "inference_training": {
        "optimizer": "AdamW", 
        "learning_rate": 1e-4,
        "weight_decay": 0.01,
        "scheduler": "CosineAnnealingLR",
        "num_epochs": 100,
        "early_stopping_patience": 15,
    }
}

# 数据增强配置
AUGMENTATION_CONFIG = {
    "image_augmentations": {
        "horizontal_flip": 0.5,
        "rotation": 10,
        "color_jitter": {
            "brightness": 0.2,
            "contrast": 0.2,
            "saturation": 0.2,
            "hue": 0.1,
        },
        "random_crop": True,
        "resize": (224, 224),
    },
    "text_augmentations": {
        "random_mask": 0.1,
        "synonym_replacement": 0.1,
        "random_insertion": 0.05,
        "random_swap": 0.05,
    }
}

# 评估配置
EVALUATION_CONFIG = {
    "metrics": ["accuracy", "precision", "recall", "f1", "auc"],
    "use_cpa": True,
    "cpa_temperature": 0.07,
    "num_augmentations": 3,
}

# 日志配置
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "file": "training.log",
    "console": True,
}

# 检查点配置
CHECKPOINT_CONFIG = {
    "save_dir": "./checkpoints",
    "save_frequency": 10,  # 每10个epoch保存一次
    "keep_last_n": 5,  # 保留最后5个检查点
    "save_best": True,
    "monitor_metric": "val_accuracy",
    "mode": "max",
}
