"""
双实例级提示和掩码条件混合

实现Dual Instance-level Prompts via Mask-conditioned Mixing
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional
import math


class DualInstancePrompts(nn.Module):
    """
    双实例级提示和掩码条件混合 - 
    
    实现论文中的双分支设计：
    - 专业化分支 P^sp = g_sp(u, P^mod(m))
    - 泛化分支 P^gn = g_gn(u, P^mod(m))
    - 掩码条件门控 ω = σ(w^T [Hash(m) || MLP(u)])
    - 混合提示 P̃^ins = ω P^sp + (1-ω) P^gn
    """
    
    def __init__(self, hidden_size: int, num_modalities: int, prompt_length: int, num_layers: int):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        self.prompt_length = prompt_length
        self.num_layers = num_layers
        
        # 内容聚合器 ψ
        self.content_aggregator = ContentAggregator(hidden_size, num_modalities)
        
        # 专业化分支 g_sp
        self.specialization_branch = nn.ModuleList([
            self._build_prompt_generator(hidden_size, prompt_length)
            for _ in range(num_layers)
        ])
        
        # 泛化分支 g_gn
        self.generalization_branch = nn.ModuleList([
            self._build_prompt_generator(hidden_size, prompt_length)
            for _ in range(num_layers)
        ])
        
        # 掩码哈希函数 Hash(m)
        self.mask_hash = nn.Linear(num_modalities, hidden_size // 4)
        
        # 内容MLP MLP(u)
        self.content_mlp = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, hidden_size // 4)
        )
        
        # 门控网络 ω = σ(w^T [Hash(m) || MLP(u)])
        gate_input_dim = hidden_size // 4 + hidden_size // 4  # mask_hash + content_mlp
        self.gate_network = nn.Sequential(
            nn.Linear(gate_input_dim, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, 1),
            nn.Sigmoid()
        )
        
        self._init_parameters()
    
    def _build_prompt_generator(self, hidden_size: int, prompt_length: int) -> nn.Module:
        """构建提示生成器"""
        return nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size * 2),  # [u, P^mod] 拼接
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size * 2, prompt_length * hidden_size)
        )
    
    def _init_parameters(self):
        """初始化参数"""
        for branch in [self.specialization_branch, self.generalization_branch]:
            for layer in branch:
                for module in layer:
                    if isinstance(module, nn.Linear):
                        nn.init.normal_(module.weight, std=0.02)
                        nn.init.zeros_(module.bias)
    
    def _compute_content_summary(self, modality_tokens: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        计算内容摘要 u = ψ(x)
        
        论文公式：
        u = ψ(x) = LN([Pool(t^(1)) || ... || Pool(t^(M))])
        """
        return self.content_aggregator(modality_tokens)
    
    def _compute_gate(self, missing_mask: torch.Tensor, content_summary: torch.Tensor) -> torch.Tensor:
        """
        计算门控权重 ω = σ(w^T [Hash(m) || MLP(u)])
        
        论文公式：
        ω = σ(w^T [Hash(m) || MLP(u)]) ∈ [0, 1]
        """
        # 掩码哈希 Hash(m)
        mask_hash = self.mask_hash(missing_mask.float())  # (B, d//4)
        
        # 内容MLP MLP(u)
        content_mlp = self.content_mlp(content_summary)  # (B, d//4)
        
        # 拼接并计算门控
        gate_input = torch.cat([mask_hash, content_mlp], dim=-1)  # (B, d//2)
        gate_weight = self.gate_network(gate_input)  # (B, 1)
        
        return gate_weight
    
    def forward(self, modality_tokens: Dict[str, torch.Tensor], 
                modality_prompts: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
        """
        前向传播 - 
        
        Args:
            modality_tokens: 各模态标记 {modality: (B, L_k, d)}
            modality_prompts: 模态级提示 {layer_idx: (B, prompt_length, d)}
            
        Returns:
            dict: 混合后的实例级提示 {layer_idx: (B, prompt_length, d)}
        """
        batch_size = next(iter(modality_tokens.values())).shape[0]
        device = next(iter(modality_tokens.values())).device
        
        # 1. 计算内容摘要 u = ψ(x)
        content_summary = self._compute_content_summary(modality_tokens)  # (B, d)
        
        # 2. 计算门控权重 ω = σ(w^T [Hash(m) || MLP(u)])
        # 这里需要从modality_tokens推断missing_mask，简化处理
        missing_mask = self._infer_missing_mask(modality_tokens)
        gate_weight = self._compute_gate(missing_mask, content_summary)  # (B, 1)
        
        # 3. 为每层生成混合提示
        mixed_prompts = {}
        for layer_idx in range(self.num_layers):
            # 获取该层的模态级提示
            layer_modality_prompt = modality_prompts[layer_idx]  # (B, prompt_length, d)
            
            # 拼接内容摘要和模态级提示
            combined_input = torch.cat([
                content_summary.unsqueeze(1).expand(-1, self.prompt_length, -1),  # (B, prompt_length, d)
                layer_modality_prompt  # (B, prompt_length, d)
            ], dim=-1)  # (B, prompt_length, 2d)
            
            # 重塑为 (B, 2d) 用于线性层
            combined_flat = combined_input.view(batch_size, -1)  # (B, prompt_length * 2d)
            
            # 专业化分支 P^sp = g_sp(u, P^mod(m))
            sp_prompts = self.specialization_branch[layer_idx](combined_flat)  # (B, prompt_length * d)
            sp_prompts = sp_prompts.view(batch_size, self.prompt_length, self.hidden_size)
            
            # 泛化分支 P^gn = g_gn(u, P^mod(m))
            gn_prompts = self.generalization_branch[layer_idx](combined_flat)  # (B, prompt_length * d)
            gn_prompts = gn_prompts.view(batch_size, self.prompt_length, self.hidden_size)
            
            # 混合两个分支 P̃^ins = ω P^sp + (1-ω) P^gn
            mixed_prompt = gate_weight.unsqueeze(-1) * sp_prompts + \
                          (1 - gate_weight.unsqueeze(-1)) * gn_prompts  # (B, prompt_length, d)
            
            mixed_prompts[layer_idx] = mixed_prompt
        
        return mixed_prompts
    
    def _infer_missing_mask(self, modality_tokens: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        从模态标记推断缺失掩码
        
        这是一个简化的实现，实际中应该从输入数据中获取
        """
        batch_size = next(iter(modality_tokens.values())).shape[0]
        device = next(iter(modality_tokens.values())).device
        
        # 简化处理：假设所有模态都存在
        missing_mask = torch.ones(batch_size, self.num_modalities, device=device)
        return missing_mask


class ContentAggregator(nn.Module):
    """
    内容聚合器 ψ
    
    实现论文公式：
    u = ψ(x) = LN([Pool(t^(1)) || ... || Pool(t^(M))])
    """
    
    def __init__(self, hidden_size: int, num_modalities: int):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        
        # 层归一化
        self.layer_norm = nn.LayerNorm(hidden_size * num_modalities)
        
        # 投影到隐藏维度
        self.projection = nn.Linear(hidden_size * num_modalities, hidden_size)
    
    def forward(self, modality_tokens: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        聚合内容信息
        
        Args:
            modality_tokens: 各模态标记 {modality: (B, L_k, d)}
            
        Returns:
            torch.Tensor: 内容摘要 u (B, d)
        """
        pooled_tokens = []
        
        # 池化各模态标记
        for modality, tokens in modality_tokens.items():
            # 平均池化
            pooled = tokens.mean(dim=1)  # (B, d)
            pooled_tokens.append(pooled)
        
        # 拼接所有模态
        if pooled_tokens:
            combined = torch.cat(pooled_tokens, dim=-1)  # (B, M*d)
        else:
            batch_size = next(iter(modality_tokens.values())).shape[0]
            combined = torch.zeros(batch_size, self.hidden_size * self.num_modalities,
                                 device=next(iter(modality_tokens.values())).device)
        
        # 层归一化
        normalized = self.layer_norm(combined)
        
        # 投影到隐藏维度
        content_summary = self.projection(normalized)
        
        return content_summary


class MaskConditionedGate(nn.Module):
    """
    掩码条件门控模块
    
    实现论文公式：
    ω = σ(w^T [Hash(m) || MLP(u)]) ∈ [0, 1]
    """
    
    def __init__(self, hidden_size: int, num_modalities: int):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        
        # 掩码哈希函数 Hash(m)
        self.mask_hash = nn.Linear(num_modalities, hidden_size // 4)
        
        # 内容MLP MLP(u)
        self.content_mlp = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, hidden_size // 4)
        )
        
        # 门控网络
        gate_input_dim = hidden_size // 4 + hidden_size // 4
        self.gate_network = nn.Sequential(
            nn.Linear(gate_input_dim, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, 1),
            nn.Sigmoid()
        )
    
    def forward(self, missing_mask: torch.Tensor, content_summary: torch.Tensor) -> torch.Tensor:
        """
        计算门控权重
        
        Args:
            missing_mask: 缺失掩码 (B, M)
            content_summary: 内容摘要 (B, d)
            
        Returns:
            torch.Tensor: 门控权重 (B, 1)
        """
        # 掩码哈希
        mask_hash = self.mask_hash(missing_mask.float())  # (B, d//4)
        
        # 内容MLP
        content_mlp = self.content_mlp(content_summary)  # (B, d//4)
        
        # 拼接并计算门控
        gate_input = torch.cat([mask_hash, content_mlp], dim=-1)  # (B, d//2)
        gate_weight = self.gate_network(gate_input)  # (B, 1)
        
        return gate_weight


class PromptMixer(nn.Module):
    """
    提示混合器
    
    实现论文公式：
    P̃^ins = ω P^sp + (1-ω) P^gn
    """
    
    def __init__(self):
        super().__init__()
    
    def forward(self, sp_prompts: torch.Tensor, gn_prompts: torch.Tensor, 
                gate_weight: torch.Tensor) -> torch.Tensor:
        """
        混合专业化提示和泛化提示
        
        Args:
            sp_prompts: 专业化提示 (B, prompt_length, d)
            gn_prompts: 泛化提示 (B, prompt_length, d)
            gate_weight: 门控权重 (B, 1)
            
        Returns:
            torch.Tensor: 混合后的提示 (B, prompt_length, d)
        """
        # 凸组合：P̃^ins = ω P^sp + (1-ω) P^gn
        mixed_prompts = gate_weight.unsqueeze(-1) * sp_prompts + \
                       (1 - gate_weight.unsqueeze(-1)) * gn_prompts
        
        return mixed_prompts
