import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional
import math

try:
    import pytorch_lightning as pl
    _BaseLM = pl.LightningModule
except Exception:
    class _LightningModuleShim(nn.Module):
        def __init__(self):
            super().__init__()
        def save_hyperparameters(self):
            pass
    pl = None
    _BaseLM = _LightningModuleShim

from ..modules.vilt_module import ViLTransformerSS
from .absence_aware_prompts import AbsenceAwareModalityPrompts, DualInstancePrompts
from .hierarchical_distillation import TeacherModel, InferenceModel, HierarchicalDistillation
from .hard_negative_contrastive import HardNegativeContrastive
from .calibrated_prompt_adaptation import CalibratedPromptAdaptation


class AbsenceAwareDistillationModel(_BaseLM):
    
    def __init__(self, config):
        super().__init__()
        
        # 保存超参数
        try:
            self.save_hyperparameters()
        except Exception:
            pass
        
        if not hasattr(self, 'hparams') or not hasattr(self, 'hparams') or not hasattr(getattr(self, 'hparams'), 'config'):
            class _HP: pass
            self.hparams = _HP()
            self.hparams.config = dict(config)
        
        # 基础配置
        self.hidden_size = config["hidden_size"]
        self.num_modalities = config.get("num_modalities", 2)  # 默认文本+图像
        self.num_classes = config.get("num_classes", 2)
        self.prompt_length = config.get("prompt_length", 4)
        self.num_prompt_layers = config.get("num_prompt_layers", 4)
        
        # 初始化冻结的骨干网络
        self._init_frozen_backbones(config)
        
        # 初始化核心组件
        self._init_absence_aware_prompts(config)
        self._init_dual_instance_prompts(config)
        self._init_teacher_inference_models(config)
        self._init_hierarchical_distillation(config)
        self._init_hard_negative_contrastive(config)
        self._init_calibrated_adaptation(config)
        
        # 初始化分类头
        self._init_classification_heads(config)
        
        # 设置指标和任务
        self._setup_metrics_and_tasks()
        
        # 冻结骨干网络参数
        self._freeze_backbone_parameters()
    
    def _init_frozen_backbones(self, config):
        """初始化冻结的骨干网络（文本编码器、视觉编码器、跨模态融合器）"""
        # 文本编码器 (BERT)
        from transformers.models.bert.modeling_bert import BertConfig, BertEmbeddings
        bert_config = BertConfig(
            vocab_size=config["vocab_size"],
            hidden_size=config["hidden_size"],
            num_hidden_layers=config["num_layers"],
            num_attention_heads=config["num_heads"],
            intermediate_size=config["hidden_size"] * config["mlp_ratio"],
            max_position_embeddings=config["max_text_len"],
            hidden_dropout_prob=config["drop_rate"],
            attention_probs_dropout_prob=config["drop_rate"],
        )
        self.text_encoder = BertEmbeddings(bert_config)
        self.token_type_embeddings = nn.Embedding(2, config["hidden_size"])
        
        # 视觉编码器 (ViT)
        from ..modules.vision_transformer_prompts import VisionTransformer
        self.vision_encoder = VisionTransformer(pretrained=True, config=config)
        
        # 跨模态融合器 (ViLT Transformer)
        self.fusion_transformer = ViLTransformerSS(config)
        
        # 空标记序列用于缺失模态
        self.null_tokens = nn.Parameter(
            torch.randn(self.num_modalities, config["max_image_len"], config["hidden_size"])
        )
    
    def _init_absence_aware_prompts(self, config):
        """初始化缺失感知的模态级提示"""
        self.modality_prompts = AbsenceAwareModalityPrompts(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            prompt_length=self.prompt_length,
            num_layers=self.num_prompt_layers
        )
    
    def _init_dual_instance_prompts(self, config):
        """初始化双实例级提示和掩码条件混合"""
        self.dual_prompts = DualInstancePrompts(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            prompt_length=self.prompt_length,
            num_layers=self.num_prompt_layers
        )
    
    def _init_teacher_inference_models(self, config):
        """初始化教师和推理模型"""
        self.teacher_model = TeacherModel(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            fusion_transformer=self.fusion_transformer
        )
        
        self.inference_model = InferenceModel(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            fusion_transformer=self.fusion_transformer,
            modality_prompts=self.modality_prompts,
            dual_prompts=self.dual_prompts
        )
    
    def _init_hierarchical_distillation(self, config):
        """初始化分层蒸馏"""
        self.hierarchical_distillation = HierarchicalDistillation(
            hidden_size=self.hidden_size,
            selected_layers=config.get("selected_layers", [4, 8, 12]),
            temperature=config.get("distillation_temperature", 4.0)
        )
    
    def _init_hard_negative_contrastive(self, config):
        """初始化硬负样本对比正则化"""
        self.hard_negative_contrastive = HardNegativeContrastive(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            temperature=config.get("contrastive_temperature", 0.07),
            top_k=config.get("top_k_negatives", 5)
        )
    
    def _init_calibrated_adaptation(self, config):
        """初始化校准提示适应"""
        self.calibrated_adaptation = CalibratedPromptAdaptation(
            hidden_size=self.hidden_size,
            adaptation_lr=config.get("adaptation_lr", 0.01),
            entropy_weight=config.get("entropy_weight", 1.0),
            alignment_weight=config.get("alignment_weight", 0.1)
        )
    
    def _init_classification_heads(self, config):
        """初始化分类头"""
        self.classifier = nn.Linear(self.hidden_size, self.num_classes)
        self.mask_reconstruction_head = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size // 2),
            nn.ReLU(),
            nn.Linear(self.hidden_size // 2, self.num_modalities),
            nn.Sigmoid()
        )
    
    def _setup_metrics_and_tasks(self):
        """设置指标和任务"""
        self.current_tasks = []
        self.records = {}
    
    def _freeze_backbone_parameters(self):
        """冻结骨干网络参数"""
        for param in self.text_encoder.parameters():
            param.requires_grad = False
        for param in self.vision_encoder.parameters():
            param.requires_grad = False
        for param in self.fusion_transformer.parameters():
            param.requires_grad = False
        for param in self.token_type_embeddings.parameters():
            param.requires_grad = False
    
    def encode_modalities(self, batch):
        """
        编码各个模态
        
        Args:
            batch: 输入批次，包含文本、图像和缺失模态信息
            
        Returns:
            dict: 包含各模态编码结果的字典
        """
        # 提取输入数据
        text_ids = batch["text_ids"]
        text_masks = batch["text_masks"]
        images = batch["image"][0] if isinstance(batch["image"], tuple) else batch["image"]
        missing_mask = batch["missing_type"]  # 二进制掩码 m
        
        # 文本编码
        text_embeds = self.text_encoder(text_ids)
        text_embeds = text_embeds + self.token_type_embeddings(torch.zeros_like(text_masks))
        
        # 图像编码
        image_embeds, image_masks, patch_index, image_labels = self.vision_encoder.visual_embed(
            images,
            max_image_len=self.hparams.config["max_image_len"],
            mask_it=False,
        )
        image_embeds = image_embeds + self.token_type_embeddings(
            torch.full_like(image_masks, 1)
        )
        
        # 处理缺失模态 - 用空标记替换
        present_indices = torch.where(missing_mask == 1)[0]
        absent_indices = torch.where(missing_mask == 0)[0]
        
        # 为缺失的模态使用空标记
        if len(absent_indices) > 0:
            for idx in absent_indices:
                # 根据缺失类型选择对应的空标记
                missing_type = batch["missing_type"][idx].item()
                if missing_type == 1:  # 缺失文本
                    text_embeds[idx] = self.null_tokens[0].unsqueeze(0).expand_as(text_embeds[idx])
                elif missing_type == 2:  # 缺失图像
                    image_embeds[idx] = self.null_tokens[1].unsqueeze(0).expand_as(image_embeds[idx])
        
        return {
            "text_embeds": text_embeds,
            "text_masks": text_masks,
            "image_embeds": image_embeds,
            "image_masks": image_masks,
            "missing_mask": missing_mask,
            "patch_index": patch_index,
            "image_labels": image_labels
        }
    
    def forward(self, batch):
        """
        前向传播
        
        Args:
            batch: 输入批次
            
        Returns:
            dict: 模型输出，包含预测和损失
        """
        ret = dict()
        
        if len(self.current_tasks) == 0:
            ret.update(self.infer(batch))
            return ret
        
        # 编码各模态
        modality_encodings = self.encode_modalities(batch)
        
        # 生成缺失感知的模态级提示
        modality_prompts = self.modality_prompts(modality_encodings["missing_mask"])
        
        # 生成双实例级提示
        instance_prompts = self.dual_prompts(
            modality_encodings, 
            modality_prompts
        )
        
        # 教师模型前向传播（仅在完整数据上）
        teacher_outputs = None
        if "labels" in batch:
            teacher_outputs = self.teacher_model(modality_encodings)
        
        # 推理模型前向传播
        inference_outputs = self.inference_model(
            modality_encodings,
            modality_prompts,
            instance_prompts
        )
        
        # 计算各种损失
        losses = self._compute_losses(
            batch, 
            modality_encodings,
            modality_prompts,
            instance_prompts,
            teacher_outputs,
            inference_outputs
        )
        
        ret.update(inference_outputs)
        ret.update(losses)
        
        return ret
    
    def _compute_losses(self, batch, modality_encodings, modality_prompts, 
                       instance_prompts, teacher_outputs, inference_outputs):
        """计算各种损失"""
        losses = {}
        
        # 1. 任务损失（分类损失）
        if "labels" in batch:
            labels = batch["labels"].long().view(-1)
            cls_loss = F.cross_entropy(inference_outputs["logits"], labels)
            losses["loss/cls"] = cls_loss
        
        # 2. 掩码重构损失
        mask_recon_loss = self._compute_mask_reconstruction_loss(
            modality_prompts, modality_encodings["missing_mask"]
        )
        losses["loss/abs"] = mask_recon_loss
        
        # 3. 分层蒸馏损失
        if teacher_outputs is not None:
            distill_losses = self.hierarchical_distillation(
                teacher_outputs, inference_outputs, modality_encodings["missing_mask"]
            )
            losses.update(distill_losses)
        
        # 4. 硬负样本对比损失
        if "labels" in batch:
            contrastive_loss = self.hard_negative_contrastive(
                inference_outputs["features"],
                batch["labels"],
                teacher_outputs["logits"] if teacher_outputs else None
            )
            losses["loss/hno"] = contrastive_loss
        
        return losses
    
    def _compute_mask_reconstruction_loss(self, modality_prompts, missing_mask):
        """计算掩码重构损失"""
        # 从模态级提示重构缺失掩码
        reconstructed_mask = self.mask_reconstruction_head(
            modality_prompts.mean(dim=1)  # 池化提示
        )
        return F.binary_cross_entropy(reconstructed_mask, missing_mask.float())
    
    def infer(self, batch):
        """推理模式"""
        # 编码各模态
        modality_encodings = self.encode_modalities(batch)
        
        # 生成缺失感知的模态级提示
        modality_prompts = self.modality_prompts(modality_encodings["missing_mask"])
        
        # 生成双实例级提示
        instance_prompts = self.dual_prompts(
            modality_encodings, 
            modality_prompts
        )
        
        # 推理模型前向传播
        inference_outputs = self.inference_model(
            modality_encodings,
            modality_prompts,
            instance_prompts
        )
        
        # 应用校准提示适应
        if self.training:
            adapted_prompts = self.calibrated_adaptation(
                instance_prompts,
                inference_outputs["features"],
                modality_encodings
            )
            # 使用适应后的提示重新计算
            inference_outputs = self.inference_model(
                modality_encodings,
                modality_prompts,
                adapted_prompts
            )
        
        return inference_outputs
    
    def training_step(self, batch, batch_idx):
        """训练步骤"""
        output = self(batch)
        total_loss = sum([v for k, v in output.items() if "loss" in k])
        return total_loss
    
    def validation_step(self, batch, batch_idx):
        """验证步骤"""
        output = self(batch)
        return output
    
    def test_step(self, batch, batch_idx):
        """测试步骤"""
        output = self.infer(batch)
        return output
    
    def configure_optimizers(self):
        """配置优化器"""
        # 只优化可学习的参数（提示、门控、适配器等）
        learnable_params = []
        for name, param in self.named_parameters():
            if param.requires_grad:
                learnable_params.append(param)
        
        optimizer = torch.optim.AdamW(learnable_params, lr=1e-4, weight_decay=0.01)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=100)
        
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "interval": "epoch"
            }
        }
