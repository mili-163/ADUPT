"""
1. 缺失感知的模态级提示 (Absence-aware Modality-level Prompts)
2. 双实例级提示和掩码条件混合 (Dual Instance-level Prompts via Mask-conditioned Mixing)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional
import math


class AbsenceAwareModalityPrompts(nn.Module):
    """
    缺失感知的模态级提示
    
    根据论文公式(1)，将缺失掩码m映射为小的标记集合，注入到L个transformer层中：
    P^mod(m) = φ([∑_k m_k E^(+)_k || ∑_k (1-m_k) E^(-)_k])
    
    其中：
    - E^(+), E^(-) ∈ R^(M×d) 是可学习的存在/缺失嵌入
    - || 是拼接操作
    - φ 是一个小的MLP
    """
    
    def __init__(self, hidden_size: int, num_modalities: int, prompt_length: int, num_layers: int):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        self.prompt_length = prompt_length
        self.num_layers = num_layers
        
        # 存在和缺失嵌入 E^(+), E^(-) ∈ R^(M×d)
        self.presence_embeddings = nn.Parameter(
            torch.randn(num_modalities, hidden_size)
        )
        self.absence_embeddings = nn.Parameter(
            torch.randn(num_modalities, hidden_size)
        )
        
        # 小的MLP φ，将拼接后的嵌入映射为提示
        self.prompt_mlp = nn.Sequential(
            nn.Linear(2 * hidden_size, hidden_size * 2),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size * 2, hidden_size),
            nn.GELU(),
        )
        
        # 为每个层生成不同的提示
        self.layer_prompts = nn.ModuleList([
            nn.Linear(hidden_size, prompt_length * hidden_size)
            for _ in range(num_layers)
        ])
        
        # 初始化参数
        self._init_parameters()
    
    def _init_parameters(self):
        """初始化参数"""
        nn.init.normal_(self.presence_embeddings, std=0.02)
        nn.init.normal_(self.absence_embeddings, std=0.02)
        
        for layer_prompt in self.layer_prompts:
            nn.init.normal_(layer_prompt.weight, std=0.02)
            nn.init.zeros_(layer_prompt.bias)
    
    def forward(self, missing_mask: torch.Tensor) -> Dict[int, torch.Tensor]:
        """
        前向传播
        
        Args:
            missing_mask: 缺失掩码 (B, M)，其中1表示存在，0表示缺失
            
        Returns:
            dict: 每层的提示 {layer_idx: (B, prompt_length, hidden_size)}
        """
        batch_size = missing_mask.shape[0]
        device = missing_mask.device
        
        # 计算存在和缺失的加权和
        # ∑_k m_k E^(+)_k
        presence_sum = torch.matmul(missing_mask.float(), self.presence_embeddings)  # (B, d)
        
        # ∑_k (1-m_k) E^(-)_k  
        absence_sum = torch.matmul((1 - missing_mask.float()), self.absence_embeddings)  # (B, d)
        
        # 拼接 [presence_sum || absence_sum]
        combined = torch.cat([presence_sum, absence_sum], dim=-1)  # (B, 2d)
        
        # 通过MLP φ映射
        prompt_features = self.prompt_mlp(combined)  # (B, d)
        
        # 为每个层生成提示
        layer_prompts = {}
        for layer_idx, layer_prompt in enumerate(self.layer_prompts):
            # 生成该层的提示
            layer_prompt_tokens = layer_prompt(prompt_features)  # (B, prompt_length * d)
            layer_prompt_tokens = layer_prompt_tokens.view(
                batch_size, self.prompt_length, self.hidden_size
            )  # (B, prompt_length, d)
            layer_prompts[layer_idx] = layer_prompt_tokens
        
        return layer_prompts
    
    def reconstruct_mask(self, layer_prompts: Dict[int, torch.Tensor]) -> torch.Tensor:
        """
        从提示重构缺失掩码（用于损失计算）
        
        Args:
            layer_prompts: 每层的提示
            
        Returns:
            torch.Tensor: 重构的缺失掩码 (B, M)
        """
        # 使用第一层的提示进行重构
        first_layer_prompt = layer_prompts[0]  # (B, prompt_length, d)
        pooled_prompt = first_layer_prompt.mean(dim=1)  # (B, d)
        
        # 通过分类头重构掩码
        reconstructed = torch.sigmoid(
            torch.matmul(pooled_prompt, self.presence_embeddings.t())
        )  # (B, M)
        
        return reconstructed


class DualInstancePrompts(nn.Module):
    """
    双实例级提示和掩码条件混合
    
    实现论文中的双分支设计：
    - 专业化分支 P^sp = g_sp(u, P^mod(m))
    - 泛化分支 P^gn = g_gn(u, P^mod(m))
    - 掩码条件门控 ω = σ(w^T [Hash(m) || MLP(u)])
    - 混合提示 P̃^ins = ω P^sp + (1-ω) P^gn
    """
    
    def __init__(self, hidden_size: int, num_modalities: int, prompt_length: int, num_layers: int):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        self.prompt_length = prompt_length
        self.num_layers = num_layers
        
        # 内容聚合函数 ψ
        self.content_aggregator = nn.Sequential(
            nn.LayerNorm(hidden_size),
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, hidden_size)
        )
        
        # 专业化分支 g_sp
        self.specialization_branch = nn.ModuleList([
            self._build_prompt_generator(hidden_size, prompt_length)
            for _ in range(num_layers)
        ])
        
        # 泛化分支 g_gn
        self.generalization_branch = nn.ModuleList([
            self._build_prompt_generator(hidden_size, prompt_length)
            for _ in range(num_layers)
        ])
        
        # 掩码哈希函数（简单的线性变换）
        self.mask_hash = nn.Linear(num_modalities, hidden_size // 4)
        
        # 内容MLP
        self.content_mlp = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, hidden_size // 4)
        )
        
        # 门控网络
        gate_input_dim = hidden_size // 4 + hidden_size // 4  # mask_hash + content_mlp
        self.gate_network = nn.Sequential(
            nn.Linear(gate_input_dim, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, 1),
            nn.Sigmoid()
        )
        
        self._init_parameters()
    
    def _build_prompt_generator(self, hidden_size: int, prompt_length: int) -> nn.Module:
        """构建提示生成器"""
        return nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size * 2),  # [u, P^mod] 拼接
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size * 2, prompt_length * hidden_size)
        )
    
    def _init_parameters(self):
        """初始化参数"""
        for branch in [self.specialization_branch, self.generalization_branch]:
            for layer in branch:
                for module in layer:
                    if isinstance(module, nn.Linear):
                        nn.init.normal_(module.weight, std=0.02)
                        nn.init.zeros_(module.bias)
    
    def _aggregate_content(self, modality_encodings: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        聚合内容信息 u = ψ(x)
        
        Args:
            modality_encodings: 各模态编码结果
            
        Returns:
            torch.Tensor: 内容摘要 (B, d)
        """
        # 池化各模态的标记
        pooled_tokens = []
        
        # 文本池化
        if "text_embeds" in modality_encodings:
            text_pooled = modality_encodings["text_embeds"].mean(dim=1)  # (B, d)
            pooled_tokens.append(text_pooled)
        
        # 图像池化
        if "image_embeds" in modality_encodings:
            image_pooled = modality_encodings["image_embeds"].mean(dim=1)  # (B, d)
            pooled_tokens.append(image_pooled)
        
        # 拼接所有模态
        if pooled_tokens:
            combined = torch.cat(pooled_tokens, dim=-1)  # (B, M*d)
            # 投影到隐藏维度
            if combined.shape[-1] != self.hidden_size:
                proj = nn.Linear(combined.shape[-1], self.hidden_size).to(combined.device)
                combined = proj(combined)
        else:
            batch_size = next(iter(modality_encodings.values())).shape[0]
            combined = torch.zeros(batch_size, self.hidden_size, device=next(iter(modality_encodings.values())).device)
        
        # 通过内容聚合器
        content_summary = self.content_aggregator(combined)
        return content_summary
    
    def _compute_gate(self, missing_mask: torch.Tensor, content_summary: torch.Tensor) -> torch.Tensor:
        """
        计算门控权重 ω = σ(w^T [Hash(m) || MLP(u)])
        
        Args:
            missing_mask: 缺失掩码 (B, M)
            content_summary: 内容摘要 (B, d)
            
        Returns:
            torch.Tensor: 门控权重 (B, 1)
        """
        # 掩码哈希
        mask_hash = self.mask_hash(missing_mask.float())  # (B, d//4)
        
        # 内容MLP
        content_mlp = self.content_mlp(content_summary)  # (B, d//4)
        
        # 拼接并计算门控
        gate_input = torch.cat([mask_hash, content_mlp], dim=-1)  # (B, d//2)
        gate_weight = self.gate_network(gate_input)  # (B, 1)
        
        return gate_weight
    
    def forward(self, modality_encodings: Dict[str, torch.Tensor], 
                modality_prompts: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
        """
        前向传播
        
        Args:
            modality_encodings: 各模态编码结果
            modality_prompts: 模态级提示
            
        Returns:
            dict: 混合后的实例级提示 {layer_idx: (B, prompt_length, hidden_size)}
        """
        batch_size = next(iter(modality_encodings.values())).shape[0]
        device = next(iter(modality_encodings.values())).device
        
        # 聚合内容信息
        content_summary = self._aggregate_content(modality_encodings)  # (B, d)
        
        # 计算门控权重
        missing_mask = modality_encodings["missing_mask"]  # (B, M)
        gate_weight = self._compute_gate(missing_mask, content_summary)  # (B, 1)
        
        # 为每层生成混合提示
        mixed_prompts = {}
        for layer_idx in range(self.num_layers):
            # 获取该层的模态级提示
            layer_modality_prompt = modality_prompts[layer_idx]  # (B, prompt_length, d)
            
            # 拼接内容摘要和模态级提示
            combined_input = torch.cat([
                content_summary.unsqueeze(1).expand(-1, self.prompt_length, -1),  # (B, prompt_length, d)
                layer_modality_prompt  # (B, prompt_length, d)
            ], dim=-1)  # (B, prompt_length, 2d)
            
            # 重塑为 (B, 2d) 用于线性层
            combined_flat = combined_input.view(batch_size, -1)  # (B, prompt_length * 2d)
            
            # 专业化分支
            sp_prompts = self.specialization_branch[layer_idx](combined_flat)  # (B, prompt_length * d)
            sp_prompts = sp_prompts.view(batch_size, self.prompt_length, self.hidden_size)
            
            # 泛化分支
            gn_prompts = self.generalization_branch[layer_idx](combined_flat)  # (B, prompt_length * d)
            gn_prompts = gn_prompts.view(batch_size, self.prompt_length, self.hidden_size)
            
            # 混合两个分支
            mixed_prompt = gate_weight.unsqueeze(-1) * sp_prompts + \
                          (1 - gate_weight.unsqueeze(-1)) * gn_prompts  # (B, prompt_length, d)
            
            mixed_prompts[layer_idx] = mixed_prompt
        
        return mixed_prompts


class MaskAdapter(nn.Module):
    """
    掩码适配器 Π_m，用于将教师特征适配到学生条件
    
    实现FiLM风格的适配器：
    Π_m(h) = γ(m) ⊙ h + β(m)
    其中 γ(m), β(m) = MLP(Hash(m))
    """
    
    def __init__(self, hidden_size: int, num_modalities: int):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        
        # 掩码哈希
        self.mask_hash = nn.Linear(num_modalities, hidden_size // 4)
        
        # FiLM参数生成器
        self.film_generator = nn.Sequential(
            nn.Linear(hidden_size // 4, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, hidden_size * 2)  # 输出 γ 和 β
        )
    
    def forward(self, features: torch.Tensor, missing_mask: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        
        Args:
            features: 输入特征 (B, d)
            missing_mask: 缺失掩码 (B, M)
            
        Returns:
            torch.Tensor: 适配后的特征 (B, d)
        """
        # 掩码哈希
        mask_hash = self.mask_hash(missing_mask.float())  # (B, d//4)
        
        # 生成FiLM参数
        film_params = self.film_generator(mask_hash)  # (B, 2d)
        gamma, beta = torch.chunk(film_params, 2, dim=-1)  # 各 (B, d)
        
        # 应用FiLM变换
        adapted_features = gamma * features + beta  # (B, d)
        
        return adapted_features
