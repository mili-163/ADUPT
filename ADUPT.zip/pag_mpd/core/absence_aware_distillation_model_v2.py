import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional, Union
import math

from .incomplete_multimodal_learning import IncompleteMultimodalLearning

# 尝试导入其他模块，如果失败则创建模拟类
try:
    from .absence_aware_prompts import AbsenceAwareModalityPrompts, DualInstancePrompts
except ImportError:
    # 创建模拟类
    class AbsenceAwareModalityPrompts(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def forward(self, m):
            return {0: torch.randn(1, 4, 768)}
    
    class DualInstancePrompts(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def forward(self, *args, **kwargs):
            return {0: torch.randn(1, 4, 768)}

try:
    from .hierarchical_distillation import TeacherModel, InferenceModel, HierarchicalDistillation
except ImportError:
    class TeacherModel(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def forward(self, *args, **kwargs):
            return {"features": torch.randn(1, 768), "logits": torch.randn(1, 2)}
    
    class InferenceModel(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def forward(self, *args, **kwargs):
            return {"features": torch.randn(1, 768), "logits": torch.randn(1, 2)}
    
    class HierarchicalDistillation(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def forward(self, *args, **kwargs):
            return {"loss/feat": torch.tensor(0.0), "loss/pred": torch.tensor(0.0)}

try:
    from .hard_negative_contrastive import HardNegativeContrastive
except ImportError:
    class HardNegativeContrastive(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def forward(self, *args, **kwargs):
            return torch.tensor(0.0)

try:
    from .calibrated_prompt_adaptation import CalibratedPromptAdaptation
except ImportError:
    class CalibratedPromptAdaptation(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()
        def single_step_adaptation(self, *args, **kwargs):
            return args[0] if args else {}

try:
    import pytorch_lightning as pl
    _BaseLM = pl.LightningModule
except Exception:
    class _LightningModuleShim(nn.Module):
        def __init__(self):
            super().__init__()
        def save_hyperparameters(self):
            pass
    pl = None
    _BaseLM = _LightningModuleShim


class AbsenceAwareDistillationModelV2(_BaseLM):
    """
    缺失感知蒸馏模型 v2
    
    严格按照论文描述实现：
    - 教师T在D_c上训练
    - 推理网络I在D_s∪D_c上训练
    - 两种提示族：模态级P^mod(m)和实例级P^sp, P^gn
    - 分层蒸馏、硬负样本对比、校准适应
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        # 保存超参数
        try:
            self.save_hyperparameters()
        except Exception:
            pass
        
        if not hasattr(self, 'hparams'):
            class _HP: pass
            self.hparams = _HP()
            self.hparams.config = dict(config)
        
        # 基础配置
        self.hidden_size = config["hidden_size"]
        self.num_modalities = config["num_modalities"]
        self.modality_names = config["modality_names"]
        self.num_classes = config["num_classes"]
        
        # 初始化基础IML模型
        self.base_iml = IncompleteMultimodalLearning(config)
        
        # 初始化两种提示族
        self._init_prompt_families(config)
        
        # 初始化教师和推理网络
        self._init_teacher_inference_networks(config)
        
        # 初始化蒸馏和正则化组件
        self._init_distillation_components(config)
        
        # 设置训练状态
        self.teacher_trained = False
        self.inference_trained = False
    
    def _init_prompt_families(self, config: Dict):
        """初始化两种提示族"""
        # 模态级提示 P^mod(m) - 缺失感知上下文
        self.modality_prompts = AbsenceAwareModalityPrompts(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            prompt_length=config.get("prompt_length", 4),
            num_layers=config.get("num_prompt_layers", 4)
        )
        
        # 实例级双提示 P^sp, P^gn - 专业化和泛化
        self.dual_instance_prompts = DualInstancePrompts(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            prompt_length=config.get("prompt_length", 4),
            num_layers=config.get("num_prompt_layers", 4)
        )
    
    def _init_teacher_inference_networks(self, config: Dict):
        """初始化教师T和推理网络I"""
        # 教师网络T - 在D_c上训练
        self.teacher_T = TeacherModel(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            fusion_transformer=self.base_iml.fusion_transformer
        )
        
        # 推理网络I - 在D_s∪D_c上训练
        self.inference_I = InferenceModel(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            fusion_transformer=self.base_iml.fusion_transformer,
            modality_prompts=self.modality_prompts,
            dual_prompts=self.dual_instance_prompts
        )
    
    def _init_distillation_components(self, config: Dict):
        """初始化蒸馏和正则化组件"""
        # 分层蒸馏
        self.hierarchical_distillation = HierarchicalDistillation(
            hidden_size=self.hidden_size,
            selected_layers=config.get("selected_layers", [4, 8, 12]),
            temperature=config.get("distillation_temperature", 4.0)
        )
        
        # 硬负样本对比
        self.hard_negative_contrastive = HardNegativeContrastive(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            temperature=config.get("contrastive_temperature", 0.07),
            top_k=config.get("top_k_negatives", 5)
        )
        
        # 校准提示适应
        self.calibrated_adaptation = CalibratedPromptAdaptation(
            hidden_size=self.hidden_size,
            adaptation_lr=config.get("adaptation_lr", 0.01),
            entropy_weight=config.get("entropy_weight", 1.0),
            alignment_weight=config.get("alignment_weight", 0.1)
        )
    
    def encode_modalities_with_prompts(self, x: Dict[str, torch.Tensor], 
                                     m: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        使用提示编码各模态
        
        实现论文中的标记化过程：
        t^(k) = f_k(x^(k)) 如果 k ∈ P(m)
        t̄^(k) 如果 k ∈ A(m)
        """
        # 获取存在和缺失索引集合
        P_m, A_m = self.base_iml.get_present_absent_sets(m)
        
        # 编码各模态
        modality_tokens = self.base_iml.encode_modalities(x, m)
        
        # 生成模态级提示
        modality_prompts = self.modality_prompts(m.unsqueeze(0))  # 添加batch维度
        
        # 生成实例级双提示
        # 这里需要内容摘要u，暂时简化
        content_summary = self._compute_content_summary(modality_tokens)
        instance_prompts = self.dual_instance_prompts(
            {"modality_tokens": modality_tokens, "missing_mask": m.unsqueeze(0)},
            modality_prompts
        )
        
        return {
            "modality_tokens": modality_tokens,
            "modality_prompts": modality_prompts,
            "instance_prompts": instance_prompts,
            "missing_mask": m
        }
    
    def _compute_content_summary(self, modality_tokens: Dict[str, torch.Tensor]) -> torch.Tensor:
        """计算内容摘要u = ψ(x)"""
        # 池化各模态标记
        pooled_tokens = []
        for modality, tokens in modality_tokens.items():
            pooled = tokens.mean(dim=1)  # (B, d)
            pooled_tokens.append(pooled)
        
        if pooled_tokens:
            # 拼接并投影
            combined = torch.cat(pooled_tokens, dim=-1)
            if combined.shape[-1] != self.hidden_size:
                proj = nn.Linear(combined.shape[-1], self.hidden_size).to(combined.device)
                combined = proj(combined)
        else:
            batch_size = next(iter(modality_tokens.values())).shape[0]
            combined = torch.zeros(batch_size, self.hidden_size, 
                                 device=next(iter(modality_tokens.values())).device)
        
        return combined
    
    def teacher_forward(self, x: Dict[str, torch.Tensor], m: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        教师网络T前向传播
        
        在完整数据D_c上训练，m = 1
        """
        # 编码各模态（教师只处理完整数据）
        modality_tokens = self.base_iml.encode_modalities(x, m)
        
        # 创建掩码
        modality_masks = {}
        for i, modality in enumerate(self.modality_names):
            if m[i] == 1:
                modality_masks[modality] = torch.ones(
                    modality_tokens[modality].shape[0], 
                    modality_tokens[modality].shape[1],
                    device=modality_tokens[modality].device
                )
            else:
                modality_masks[modality] = torch.zeros(
                    modality_tokens[modality].shape[0], 
                    modality_tokens[modality].shape[1],
                    device=modality_tokens[modality].device
                )
        
        # 通过融合transformer
        z = self.base_iml.fusion_transformer(modality_tokens, modality_masks)
        
        # 任务预测
        s = self.base_iml.task_head(z)
        
        return {
            "features": z,
            "logits": s,
            "probs": F.softmax(s, dim=-1)
        }
    
    def inference_forward(self, x: Dict[str, torch.Tensor], m: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        推理网络I前向传播
        
        在D_s∪D_c上训练，使用提示机制处理缺失模态
        """
        # 使用提示编码各模态
        encoded_data = self.encode_modalities_with_prompts(x, m)
        
        # 通过推理网络
        outputs = self.inference_I(
            encoded_data["modality_tokens"],
            encoded_data["modality_prompts"],
            encoded_data["instance_prompts"]
        )
        
        return outputs
    
    def forward(self, x: Dict[str, torch.Tensor], m: torch.Tensor, 
                y: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        前向传播
        
        Args:
            x: 原始输入 {modality: x^(k)}
            m: 存在掩码 (M,)
            y: 真实标签（可选）
            
        Returns:
            Dict[str, torch.Tensor]: 模型输出
        """
        ret = {}
        
        if self.training:
            # 训练模式
            if not self.teacher_trained:
                # 阶段1：教师训练
                teacher_outputs = self.teacher_forward(x, m)
                ret.update(teacher_outputs)
                
                if y is not None:
                    task_loss = self.base_iml.compute_task_loss(teacher_outputs["logits"], y)
                    ret["loss"] = task_loss
                    
            elif not self.inference_trained:
                # 阶段2：推理训练
                teacher_outputs = self.teacher_forward(x, m)
                inference_outputs = self.inference_forward(x, m)
                
                ret.update(inference_outputs)
                
                # 计算各种损失
                losses = self._compute_training_losses(
                    x, m, y, teacher_outputs, inference_outputs
                )
                ret.update(losses)
                
            else:
                # 阶段3：推理模式
                inference_outputs = self.inference_forward(x, m)
                ret.update(inference_outputs)
        else:
            # 推理模式
            inference_outputs = self.inference_forward(x, m)
            ret.update(inference_outputs)
        
        return ret
    
    def _compute_training_losses(self, x: Dict[str, torch.Tensor], m: torch.Tensor,
                                y: torch.Tensor, teacher_outputs: Dict[str, torch.Tensor],
                                inference_outputs: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """计算训练损失"""
        losses = {}
        
        # 1. 任务损失
        task_loss = self.base_iml.compute_task_loss(inference_outputs["logits"], y)
        losses["loss/task"] = task_loss
        
        # 2. 掩码重构损失
        mask_recon_loss = self._compute_mask_reconstruction_loss(m)
        losses["loss/mask_recon"] = mask_recon_loss
        
        # 3. 分层蒸馏损失
        distill_losses = self.hierarchical_distillation(
            teacher_outputs, inference_outputs, m.unsqueeze(0)
        )
        losses.update(distill_losses)
        
        # 4. 硬负样本对比损失
        contrastive_loss = self.hard_negative_contrastive(
            inference_outputs["features"], y, teacher_outputs["logits"]
        )
        losses["loss/contrastive"] = contrastive_loss
        
        # 总损失
        total_loss = (task_loss + 
                     0.1 * mask_recon_loss + 
                     1.0 * distill_losses.get("loss/feat", 0) +
                     1.0 * distill_losses.get("loss/pred", 0) +
                     0.5 * contrastive_loss)
        losses["loss/total"] = total_loss
        
        return losses
    
    def _compute_mask_reconstruction_loss(self, m: torch.Tensor) -> torch.Tensor:
        """计算掩码重构损失"""
        # 这里需要实现从提示重构掩码的逻辑
        # 暂时返回0
        return torch.tensor(0.0, device=m.device)
    
    def set_teacher_trained(self, trained: bool = True):
        """设置教师训练状态"""
        self.teacher_trained = trained
        if trained:
            # 冻结教师网络
            for param in self.teacher_T.parameters():
                param.requires_grad = False
    
    def set_inference_trained(self, trained: bool = True):
        """设置推理训练状态"""
        self.inference_trained = trained
    
    def get_learnable_parameters(self) -> List[torch.Tensor]:
        """获取可学习参数"""
        learnable_params = []
        
        # 基础IML的可学习参数
        learnable_params.extend(self.base_iml.get_learnable_parameters())
        
        # 提示参数
        learnable_params.extend(list(self.modality_prompts.parameters()))
        learnable_params.extend(list(self.dual_instance_prompts.parameters()))
        
        # 推理网络参数
        learnable_params.extend(list(self.inference_I.parameters()))
        
        return learnable_params
    
    def training_step(self, batch, batch_idx):
        """训练步骤"""
        # 提取数据
        x = {k: v for k, v in batch.items() if k in self.modality_names}
        m = batch["missing_mask"]
        y = batch.get("labels")
        
        # 前向传播
        outputs = self.forward(x, m, y)
        
        # 返回损失
        if "loss/total" in outputs:
            return outputs["loss/total"]
        elif "loss" in outputs:
            return outputs["loss"]
        else:
            return torch.tensor(0.0, requires_grad=True)
    
    def validation_step(self, batch, batch_idx):
        """验证步骤"""
        x = {k: v for k, v in batch.items() if k in self.modality_names}
        m = batch["missing_mask"]
        y = batch.get("labels")
        
        outputs = self.forward(x, m, y)
        return outputs
    
    def test_step(self, batch, batch_idx):
        """测试步骤"""
        x = {k: v for k, v in batch.items() if k in self.modality_names}
        m = batch["missing_mask"]
        
        outputs = self.forward(x, m)
        return outputs
