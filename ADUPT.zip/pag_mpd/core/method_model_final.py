import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional, Union
import math

from .incomplete_multimodal_learning import IncompleteMultimodalLearning
from .modality_prompts_v2 import AbsenceAwareModalityPrompts, ModalityPromptInjector
from .dual_prompts_v3 import DualInstancePromptsV3, ContentAggregator
from .hierarchical_distillation import HierarchicalDistillation, TeacherModel, InferenceModel
from .hard_negative_contrastive import SpecializationContrastiveRegularizer
from .calibrated_prompt_adaptation import CalibratedPromptAdaptation
from .training_objective import PaperTrainingObjective, ParameterEfficiencyManager

try:
    import pytorch_lightning as pl
    _BaseLM = pl.LightningModule
except Exception:
    class _LightningModuleShim(nn.Module):
        def __init__(self):
            super().__init__()
        def save_hyperparameters(self):
            pass
    pl = None
    _BaseLM = _LightningModuleShim


class PaperMethodModelFinal(_BaseLM):
    """
    的最终模型
    
    实现论文中描述的完整架构：
    - 教师T在D_c上训练
    - 推理网络I在D_s∪D_c上训练
    - 两种提示族：模态级P^mod(m)和实例级P^sp, P^gn
    - 掩码条件门控ω
    - 分层蒸馏、硬负样本对比、校准适应
    - 严格按照论文公式(10)的训练目标
    """
    
    def __init__(self, config: Dict):
        super().__init__()
        
        # 保存超参数
        try:
            self.save_hyperparameters()
        except Exception:
            pass
        
        if not hasattr(self, 'hparams'):
            class _HP: pass
            self.hparams = _HP()
            self.hparams.config = dict(config)
        
        # 基础配置
        self.hidden_size = config["hidden_size"]
        self.num_modalities = config["num_modalities"]
        self.modality_names = config["modality_names"]
        self.num_classes = config["num_classes"]
        self.prompt_length = config.get("prompt_length", 4)
        self.num_prompt_layers = config.get("num_prompt_layers", 4)
        
        # 初始化基础IML模型
        self.base_iml = IncompleteMultimodalLearning(config)
        
        # 初始化两种提示族 - 
        self._init_prompt_families(config)
        
        # 初始化教师和推理网络
        self._init_teacher_inference_networks(config)
        
        # 初始化分层蒸馏
        self._init_hierarchical_distillation(config)
        
        # 初始化硬负样本对比正则化
        self._init_hard_negative_contrastive(config)
        
        # 初始化单步校准提示适应
        self._init_calibrated_prompt_adaptation(config)
        
        # 初始化训练目标
        self._init_training_objective(config)
        
        # 初始化参数效率管理器
        self.param_manager = ParameterEfficiencyManager(self)
        
        # 设置训练状态
        self.teacher_trained = False
        self.inference_trained = False
        self.cpa_enabled = False
    
    def _init_prompt_families(self, config: Dict):
        """初始化两种提示族 - """
        # 模态级提示 P^mod(m) - 缺失感知上下文
        self.modality_prompts = AbsenceAwareModalityPrompts(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            prompt_length=self.prompt_length,
            num_layers=self.num_prompt_layers
        )
        
        # 模态提示注入器
        self.prompt_injector = ModalityPromptInjector(
            hidden_size=self.hidden_size,
            prompt_length=self.prompt_length,
            num_layers=self.num_prompt_layers
        )
        
        # 实例级双提示 P^sp, P^gn - 专业化和泛化
        self.dual_instance_prompts = DualInstancePromptsV3(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            prompt_length=self.prompt_length,
            num_layers=self.num_prompt_layers
        )
    
    def _init_teacher_inference_networks(self, config: Dict):
        """初始化教师T和推理网络I"""
        # 教师网络T - 在D_c上训练
        self.teacher_T = TeacherModel(
            base_iml=self.base_iml,
            hidden_size=self.hidden_size,
            num_classes=self.num_classes
        )
        
        # 推理网络I - 在D_s∪D_c上训练
        self.inference_I = InferenceModel(
            base_iml=self.base_iml,
            modality_prompts=self.modality_prompts,
            dual_prompts=self.dual_instance_prompts,
            prompt_injector=self.prompt_injector,
            hidden_size=self.hidden_size,
            num_classes=self.num_classes
        )
    
    def _init_hierarchical_distillation(self, config: Dict):
        """初始化分层蒸馏"""
        selected_layers = config.get("selected_layers", [0])  # 选择的融合层
        temperature = config.get("distillation_temperature", 3.0)
        
        self.hierarchical_distillation = HierarchicalDistillation(
            hidden_size=self.hidden_size,
            num_modalities=self.num_modalities,
            selected_layers=selected_layers,
            temperature=temperature
        )
    
    def _init_hard_negative_contrastive(self, config: Dict):
        """初始化硬负样本对比正则化"""
        temperature = config.get("contrastive_temperature", 0.07)
        top_k = config.get("hard_negative_top_k", 5)
        
        self.contrastive_regularizer = SpecializationContrastiveRegularizer(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            temperature=temperature,
            top_k=top_k
        )
    
    def _init_calibrated_prompt_adaptation(self, config: Dict):
        """初始化单步校准提示适应"""
        eta = config.get("cpa_eta", 1.0)
        gamma = config.get("cpa_gamma", 0.01)
        
        self.calibrated_prompt_adaptation = CalibratedPromptAdaptation(
            hidden_size=self.hidden_size,
            num_classes=self.num_classes,
            eta=eta,
            gamma=gamma
        )
    
    def _init_training_objective(self, config: Dict):
        """初始化训练目标"""
        self.training_objective = PaperTrainingObjective(config)
    
    def teacher_forward(self, x: Dict[str, torch.Tensor], m: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        教师网络T前向传播
        
        在完整数据D_c上训练，m = 1
        """
        return self.teacher_T(x, m)
    
    def inference_forward(self, x: Dict[str, torch.Tensor], m: torch.Tensor, 
                         use_cpa: bool = False) -> Dict[str, torch.Tensor]:
        """
        推理网络I前向传播
        
        在D_s∪D_c上训练，使用提示机制处理缺失模态
        
        Args:
            x: 原始输入 {modality: x^(k)}
            m: 存在掩码 (M,)
            use_cpa: 是否使用单步校准提示适应
        """
        if use_cpa and self.cpa_enabled:
            return self._inference_forward_with_cpa(x, m)
        else:
            return self.inference_I(x, m)
    
    def _inference_forward_with_cpa(self, x: Dict[str, torch.Tensor], 
                                   m: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        带CPA的推理前向传播
        
        Args:
            x: 原始输入 {modality: x^(k)}
            m: 存在掩码 (M,)
            
        Returns:
            Dict[str, torch.Tensor]: 推理输出
        """
        # 1. 编码各模态
        modality_tokens = self.base_iml.encode_modalities(x, m)
        
        # 2. 生成模态级提示 P^mod(m)
        modality_prompts = self.modality_prompts(m.unsqueeze(0))
        
        # 3. 生成实例级双提示 P^sp, P^gn
        dual_outputs = self.dual_instance_prompts(
            modality_tokens, modality_prompts, return_specialization_features=True
        )
        instance_prompts = dual_outputs["mixed_prompts"]
        specialization_features = dual_outputs.get("specialization_features")
        
        # 4. 单步校准提示适应
        adapted_prompts = self.calibrated_prompt_adaptation(
            x, m, self, instance_prompts
        )
        
        # 5. 注入适应后的提示到模态标记
        processed_tokens = self.prompt_injector.inject_prompts(
            modality_tokens, adapted_prompts, m.unsqueeze(0)
        )
        
        # 6. 创建掩码（包含提示部分）
        modality_masks = {}
        for i, modality in enumerate(self.base_iml.modality_names):
            if m[i].item() == 1:
                # 模态存在：包含提示和原始标记
                total_length = processed_tokens[modality].shape[1]
                modality_masks[modality] = torch.ones(
                    processed_tokens[modality].shape[0], 
                    total_length,
                    device=processed_tokens[modality].device
                )
            else:
                # 模态缺失：只有空标记
                total_length = processed_tokens[modality].shape[1]
                modality_masks[modality] = torch.zeros(
                    processed_tokens[modality].shape[0], 
                    total_length,
                    device=processed_tokens[modality].device
                )
        
        # 7. 通过融合transformer
        z = self.base_iml.fusion_transformer(processed_tokens, modality_masks)
        
        # 8. 任务预测
        s = self.base_iml.task_head(z)
        
        result = {
            "features": z,
            "logits": s,
            "probs": F.softmax(s, dim=-1),
            "modality_prompts": modality_prompts,
            "instance_prompts": adapted_prompts
        }
        
        if specialization_features is not None:
            result["specialization_features"] = specialization_features
        
        return result
    
    def forward(self, x: Dict[str, torch.Tensor], m: torch.Tensor, 
                y: Optional[torch.Tensor] = None, use_cpa: bool = False) -> Dict[str, torch.Tensor]:
        """
        前向传播
        
        Args:
            x: 原始输入 {modality: x^(k)}
            m: 存在掩码 (M,)
            y: 真实标签（可选）
            use_cpa: 是否使用单步校准提示适应
            
        Returns:
            Dict[str, torch.Tensor]: 模型输出
        """
        ret = {}
        
        if self.training:
            # 训练模式
            if not self.teacher_trained:
                # 阶段1：教师训练
                teacher_outputs = self.teacher_forward(x, m)
                ret.update(teacher_outputs)
                
                if y is not None:
                    # 使用论文训练目标计算损失
                    losses = self.training_objective.compute_total_loss(
                        logits=teacher_outputs["logits"],
                        labels=y,
                        modality_prompts=self.modality_prompts,
                        hierarchical_distillation=self.hierarchical_distillation,
                        contrastive_regularizer=self.contrastive_regularizer,
                        teacher_outputs=None,  # 教师训练阶段没有教师输出
                        student_outputs=teacher_outputs,
                        missing_mask=m.unsqueeze(0)
                    )
                    ret.update(losses)
                    
            elif not self.inference_trained:
                # 阶段2：推理训练（带分层蒸馏和硬负样本对比）
                teacher_outputs = self.teacher_forward(x, m)
                inference_outputs = self.inference_forward(x, m, use_cpa=False)
                
                ret.update(inference_outputs)
                
                # 使用论文训练目标计算损失
                losses = self.training_objective.compute_total_loss(
                    logits=inference_outputs["logits"],
                    labels=y,
                    modality_prompts=self.modality_prompts,
                    hierarchical_distillation=self.hierarchical_distillation,
                    contrastive_regularizer=self.contrastive_regularizer,
                    teacher_outputs=teacher_outputs,
                    student_outputs=inference_outputs,
                    missing_mask=m.unsqueeze(0)
                )
                ret.update(losses)
                
            else:
                # 阶段3：推理模式
                inference_outputs = self.inference_forward(x, m, use_cpa=use_cpa)
                ret.update(inference_outputs)
        else:
            # 推理模式
            inference_outputs = self.inference_forward(x, m, use_cpa=use_cpa)
            ret.update(inference_outputs)
        
        return ret
    
    def set_teacher_trained(self, trained: bool = True):
        """设置教师训练状态"""
        self.teacher_trained = trained
        if trained:
            # 冻结教师网络
            for param in self.teacher_T.parameters():
                param.requires_grad = False
    
    def set_inference_trained(self, trained: bool = True):
        """设置推理训练状态"""
        self.inference_trained = trained
    
    def enable_cpa(self, enabled: bool = True):
        """启用/禁用单步校准提示适应"""
        self.cpa_enabled = enabled
    
    def update_teacher_statistics(self, teacher_features: torch.Tensor):
        """更新教师统计量"""
        self.calibrated_prompt_adaptation.update_teacher_statistics(teacher_features)
    
    def get_learnable_parameters(self) -> List[torch.Tensor]:
        """获取可学习参数"""
        return self.param_manager.get_learnable_parameters()
    
    def print_parameter_efficiency(self):
        """打印参数效率统计"""
        self.param_manager.print_parameter_efficiency()
    
    def get_parameter_count(self) -> Dict[str, int]:
        """获取参数统计"""
        return self.param_manager.get_parameter_count()
