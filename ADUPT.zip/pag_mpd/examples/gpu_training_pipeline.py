"""
GPU训练和测试流程
"""

import os
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from PIL import Image
import json
import time
from typing import Dict, List, Tuple, Optional
import argparse

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from core.method_model_gpu import MethodModelGPU
from core.gpu_interface import create_device_manager, wrap_dataloader_for_gpu
from configs.config import get_config
from configs.implementation_details import get_implementation_config


class MultimodalDataset(Dataset):
    
    
    def __init__(self, num_samples: int = 1000, num_modalities: int = 3, 
                 missing_rate: float = 0.3, mode: str = "train"):
        self.num_samples = num_samples
        self.num_modalities = num_modalities
        self.missing_rate = missing_rate
        self.mode = mode
        
        # 生成模拟数据
        self.data = []
        for i in range(num_samples):
            # 随机生成缺失掩码
            if mode == "train":
                # 训练时随机缺失
                missing_mask = torch.rand(num_modalities) > missing_rate
            else:
                # 测试时固定缺失模式
                missing_mask = torch.ones(num_modalities)
                if i % 3 == 0:  # 1/3的样本缺失第一个模态
                    missing_mask[0] = 0
                elif i % 3 == 1:  # 1/3的样本缺失第二个模态
                    missing_mask[1] = 0
            
            sample = {
                "text": f"Sample text {i} with some content",
                "image": np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8),
                "audio": np.random.randn(100, 74).astype(np.float32),
                "missing_mask": missing_mask.float(),
                "label": torch.randint(0, 2, (1,)).item()
            }
            self.data.append(sample)
    
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        return self.data[idx]


class TrainingPipeline:
    
    
    def __init__(self, config: Dict, device: Optional[str] = None):
        self.config = config
        self.device_manager = create_device_manager(device, auto_detect=True)
        self.device_manager.print_device_info()
        
        # 创建模型
        self.model = MethodModelGPU(config, device=device, auto_detect_device=True)
        
        # 创建优化器
        self.optimizer = self._create_optimizer()
        
        # 创建学习率调度器
        self.scheduler = self._create_scheduler()
        
        # 训练状态
        self.current_epoch = 0
        self.best_accuracy = 0.0
        self.train_losses = []
        self.val_accuracies = []
        
    def _create_optimizer(self):
        
        optimizer_config = self.config.get("implementation_details", {}).get("optimizer", {})
        
        # 只优化可学习参数
        learnable_params = self.model.get_learnable_parameters()
        
        return optim.AdamW(
            learnable_params,
            lr=optimizer_config.get("learning_rate", 1e-3),
            weight_decay=optimizer_config.get("weight_decay", 1e-4),
            betas=optimizer_config.get("betas", (0.9, 0.999))
        )
    
    def _create_scheduler(self):
        
        training_config = self.config.get("implementation_details", {}).get("training", {})
        
        return optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=training_config.get("total_epochs", 50),
            eta_min=1e-6
        )
    
    def train_epoch(self, train_loader: DataLoader) -> float:
        
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        
        for batch_idx, batch in enumerate(train_loader):
            # 移动数据到GPU
            x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
            m_batch = batch["missing_mask"]
            y_batch = batch["label"]
            
            # 移动数据到设备
            x_batch = self.device_manager.to_device(x_batch)
            m_batch = self.device_manager.to_device(m_batch)
            y_batch = self.device_manager.to_device(y_batch)
            
            # 前向传播
            self.optimizer.zero_grad()
            
            # 根据训练阶段选择不同的前向传播
            if not self.model.teacher_trained:
                # 阶段1：教师训练
                outputs = self.model.teacher_forward(x_batch, m_batch)
                loss = outputs["L_total"] if "L_total" in outputs else outputs["L_cls"]
            else:
                # 阶段2：推理训练
                outputs = self.model(x_batch, m_batch, y_batch)
                loss = outputs["L_total"]
            
            # 反向传播
            loss.backward()
            
            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.model.get_learnable_parameters(), max_norm=1.0)
            
            self.optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
            
            if batch_idx % 10 == 0:
                print(f"  Batch {batch_idx}/{len(train_loader)}, Loss: {loss.item():.4f}")
        
        return total_loss / num_batches
    
    def validate(self, val_loader: DataLoader) -> float:
        
        self.model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for batch in val_loader:
                x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
                m_batch = batch["missing_mask"]
                y_batch = batch["label"]
                
                # 移动数据到设备
                x_batch = self.device_manager.to_device(x_batch)
                m_batch = self.device_manager.to_device(m_batch)
                y_batch = self.device_manager.to_device(y_batch)
                
                # 前向传播
                outputs = self.model(x_batch, m_batch)
                logits = outputs["logits"]
                
                # 计算准确率
                predicted = logits.argmax(dim=-1)
                total += y_batch.size(0)
                correct += (predicted == y_batch).sum().item()
        
        accuracy = correct / total
        return accuracy
    
    def train(self, train_loader: DataLoader, val_loader: DataLoader, 
              num_epochs: int = 50, save_path: str = "checkpoints"):
        
        print("Started")
        
        # 创建保存目录
        os.makedirs(save_path, exist_ok=True)
        
        # 阶段1：教师训练
        print("\n阶段1：教师训练")
        print("-" * 40)
        
        teacher_epochs = self.config.get("implementation_details", {}).get("training", {}).get("teacher_epochs", 10)
        
        for epoch in range(teacher_epochs):
            print(f"Epoch {epoch+1}/{teacher_epochs}")
            
            # 训练
            train_loss = self.train_epoch(train_loader)
            self.train_losses.append(train_loss)
            
            # 验证
            val_accuracy = self.validate(val_loader)
            self.val_accuracies.append(val_accuracy)
            
            print(f"  Train Loss: {train_loss:.4f}, Val Accuracy: {val_accuracy:.4f}")
            
            # 更新学习率
            self.scheduler.step()
        
        # 设置教师训练完成
        self.model.set_teacher_trained(True)
        print("Completed")
        
        # 阶段2：推理训练
        print("\n阶段2：推理训练")
        print("-" * 40)
        
        # 重新创建优化器（可能需要不同的学习率）
        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        
        for epoch in range(teacher_epochs, num_epochs):
            print(f"Epoch {epoch+1}/{num_epochs}")
            
            # 训练
            train_loss = self.train_epoch(train_loader)
            self.train_losses.append(train_loss)
            
            # 验证
            val_accuracy = self.validate(val_loader)
            self.val_accuracies.append(val_accuracy)
            
            print(f"  Train Loss: {train_loss:.4f}, Val Accuracy: {val_accuracy:.4f}")
            
            # 保存最佳模型
            if val_accuracy > self.best_accuracy:
                self.best_accuracy = val_accuracy
                self.save_checkpoint(os.path.join(save_path, "best_model.pth"))
                print(f"   保存最佳模型 (Accuracy: {val_accuracy:.4f})")
            
            # 更新学习率
            self.scheduler.step()
        
        print(f"\n训练完成！最佳验证准确率: {self.best_accuracy:.4f}")
    
    def test(self, test_loader: DataLoader) -> Dict[str, float]:
        
        print("Started")
        
        # 加载最佳模型
        if os.path.exists("checkpoints/best_model.pth"):
            self.load_checkpoint("checkpoints/best_model.pth")
            print(" 加载最佳模型")
        
        self.model.eval()
        
        # 测试指标
        correct = 0
        total = 0
        class_correct = [0] * self.config["num_classes"]
        class_total = [0] * self.config["num_classes"]
        
        # 不同缺失模式的测试
        missing_patterns = {
            "complete": torch.ones(3),
            "missing_text": torch.tensor([0, 1, 1]),
            "missing_image": torch.tensor([1, 0, 1]),
            "missing_audio": torch.tensor([1, 1, 0]),
            "missing_text_image": torch.tensor([0, 0, 1]),
            "missing_text_audio": torch.tensor([0, 1, 0]),
            "missing_image_audio": torch.tensor([1, 0, 0])
        }
        
        results = {}
        
        for pattern_name, pattern_mask in missing_patterns.items():
            print(f"\n测试缺失模式: {pattern_name}")
            
            pattern_correct = 0
            pattern_total = 0
            
            with torch.no_grad():
                for batch in test_loader:
                    x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
                    y_batch = batch["label"]
                    
                    # 移动数据到设备
                    x_batch = self.device_manager.to_device(x_batch)
                    y_batch = self.device_manager.to_device(y_batch)
                    
                    # 使用指定的缺失模式
                    m_batch = pattern_mask.unsqueeze(0).expand(y_batch.size(0), -1)
                    m_batch = self.device_manager.to_device(m_batch)
                    
                    # 前向传播
                    outputs = self.model(x_batch, m_batch)
                    logits = outputs["logits"]
                    
                    # 计算准确率
                    predicted = logits.argmax(dim=-1)
                    pattern_total += y_batch.size(0)
                    pattern_correct += (predicted == y_batch).sum().item()
                    
                    # 更新总体统计
                    total += y_batch.size(0)
                    correct += (predicted == y_batch).sum().item()
                    
                    # 更新类别统计
                    for i in range(y_batch.size(0)):
                        label = y_batch[i].item()
                        class_correct[label] += (predicted[i] == label).item()
                        class_total[label] += 1
            
            pattern_accuracy = pattern_correct / pattern_total if pattern_total > 0 else 0
            results[pattern_name] = pattern_accuracy
            print(f"  {pattern_name} 准确率: {pattern_accuracy:.4f}")
        
        # 计算总体指标
        overall_accuracy = correct / total if total > 0 else 0
        results["overall"] = overall_accuracy
        
        # 计算每个类别的准确率
        for i in range(self.config["num_classes"]):
            if class_total[i] > 0:
                class_acc = class_correct[i] / class_total[i]
                results[f"class_{i}"] = class_acc
                print(f"  类别 {i} 准确率: {class_acc:.4f}")
        
        print(f"\n总体测试准确率: {overall_accuracy:.4f}")
        
        return results
    
    def save_checkpoint(self, path: str):
        
        checkpoint = {
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "epoch": self.current_epoch,
            "best_accuracy": self.best_accuracy,
            "train_losses": self.train_losses,
            "val_accuracies": self.val_accuracies,
            "config": self.config
        }
        torch.save(checkpoint, path)
    
    def load_checkpoint(self, path: str):
        
        checkpoint = torch.load(path, map_location=self.device_manager.get_device())
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        self.current_epoch = checkpoint["epoch"]
        self.best_accuracy = checkpoint["best_accuracy"]
        self.train_losses = checkpoint["train_losses"]
        self.val_accuracies = checkpoint["val_accuracies"]


def main():
    
    parser = argparse.ArgumentParser(description="GPU训练和测试流程")
    parser.add_argument("--mode", type=str, default="train", choices=["train", "test", "both"],
                       help="运行模式: train, test, both")
    parser.add_argument("--device", type=str, default=None, help="指定设备 (cuda, mps, cpu)")
    parser.add_argument("--epochs", type=int, default=50, help="训练轮数")
    parser.add_argument("--batch_size", type=int, default=32, help="批次大小")
    parser.add_argument("--num_samples", type=int, default=1000, help="样本数量")
    parser.add_argument("--missing_rate", type=float, default=0.3, help="缺失率")
    parser.add_argument("--save_path", type=str, default="checkpoints", help="保存路径")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("GPU训练和测试流程")
    print("=" * 60)
    
    # 获取配置
    base_config = get_config("cmu-mosi")
    implementation_config = get_implementation_config("CMU-MOSEI")
    config = {**base_config, "implementation_details": implementation_config}
    
    # 更新配置
    config["batch_size"] = args.batch_size
    config["num_samples"] = args.num_samples
    config["missing_rate"] = args.missing_rate
    
    # 创建数据集
    print("\n创建数据集...")
    train_dataset = MultimodalDataset(
        num_samples=args.num_samples, 
        missing_rate=args.missing_rate, 
        mode="train"
    )
    val_dataset = MultimodalDataset(
        num_samples=args.num_samples // 4, 
        missing_rate=args.missing_rate, 
        mode="val"
    )
    test_dataset = MultimodalDataset(
        num_samples=args.num_samples // 4, 
        missing_rate=args.missing_rate, 
        mode="test"
    )
    
    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
    
    # 包装数据加载器以支持GPU
    device_manager = create_device_manager(args.device, auto_detect=True)
    train_loader = wrap_dataloader_for_gpu(train_loader, device_manager)
    val_loader = wrap_dataloader_for_gpu(val_loader, device_manager)
    test_loader = wrap_dataloader_for_gpu(test_loader, device_manager)
    
    print(f"训练集大小: {len(train_dataset)}")
    print(f"验证集大小: {len(val_dataset)}")
    print(f"测试集大小: {len(test_dataset)}")
    
    # 创建训练流程
    pipeline = TrainingPipeline(config, device=args.device)
    
    if args.mode in ["train", "both"]:
        # 训练
        pipeline.train(train_loader, val_loader, args.epochs, args.save_path)
    
    if args.mode in ["test", "both"]:
        # 测试
        results = pipeline.test(test_loader)
        
        # 保存结果
        results_path = os.path.join(args.save_path, "test_results.json")
        with open(results_path, "w") as f:
            json.dump(results, f, indent=2)
        print(f"测试结果已保存到: {results_path}")
    
    print("Completed")


if __name__ == "__main__":
    main()
