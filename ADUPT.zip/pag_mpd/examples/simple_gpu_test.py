"""
简化的GPU测试 - 不依赖网络下载
测试GPU接口的基本功能，使用模拟数据
"""

import os
import sys
import torch
import torch.nn as nn
import numpy as np

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from core.gpu_interface import create_device_manager, wrap_model_for_gpu


class SimpleModel(nn.Module):
    
    
    def __init__(self, input_size=768, hidden_size=256, num_classes=2):
        super().__init__()
        self.linear1 = nn.Linear(input_size, hidden_size)
        self.linear2 = nn.Linear(hidden_size, num_classes)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)
    
    def forward(self, x):
        x = self.relu(self.linear1(x))
        x = self.dropout(x)
        x = self.linear2(x)
        return x


def test_device_manager():
    
    print("=" * 50)
    print("测试设备管理器")
    print("=" * 50)
    
    # 创建设备管理器
    device_manager = create_device_manager(device=None, auto_detect=True)
    device_manager.print_device_info()
    
    # 测试数据移动
    print("\n测试数据移动:")
    data = {
        "tensor": torch.randn(2, 3),
        "list": [torch.randn(1, 2), torch.randn(1, 2)],
        "nested": {
            "a": torch.randn(1, 1),
            "b": torch.randn(1, 1)
        }
    }
    
    print("原始数据设备:")
    for key, value in data.items():
        if isinstance(value, torch.Tensor):
            print(f"  {key}: {value.device}")
        elif isinstance(value, dict):
            for k, v in value.items():
                if isinstance(v, torch.Tensor):
                    print(f"  {key}.{k}: {v.device}")
    
    # 移动到设备
    moved_data = device_manager.to_device(data)
    print("\n移动后数据设备:")
    for key, value in moved_data.items():
        if isinstance(value, torch.Tensor):
            print(f"  {key}: {value.device}")
        elif isinstance(value, dict):
            for k, v in value.items():
                if isinstance(v, torch.Tensor):
                    print(f"  {key}.{k}: {v.device}")
    
    return device_manager


def test_model_wrapper(device_manager):
    
    print("\n" + "=" * 50)
    print("测试模型包装器")
    print("=" * 50)
    
    # 创建简单模型
    model = SimpleModel()
    print(f"原始模型设备: {next(model.parameters()).device}")
    
    # 包装模型
    wrapped_model = wrap_model_for_gpu(model, device_manager)
    print(f"包装后模型设备: {next(wrapped_model.parameters()).device}")
    
    # 测试前向传播
    print("\n测试前向传播:")
    batch_size = 4
    input_size = 768
    
    # 创建输入数据
    x = torch.randn(batch_size, input_size)
    print(f"输入数据设备: {x.device}")
    
    # 前向传播
    with torch.no_grad():
        output = wrapped_model(x)
        print(f"输出形状: {output.shape}")
        print(f"输出设备: {output.device}")
    
    return wrapped_model


def test_performance_benchmark(model, device_manager):
    
    print("\n" + "=" * 50)
    print("测试性能基准")
    print("=" * 50)
    
    # 测试不同批次大小
    batch_sizes = [1, 2, 4, 8]
    input_size = 768
    
    for batch_size in batch_sizes:
        print(f"\n批次大小: {batch_size}")
        try:
            # 创建测试输入
            x = torch.randn(batch_size, input_size)
            
            # 预热
            with torch.no_grad():
                for _ in range(3):
                    _ = model(x)
            
            # 基准测试
            import time
            times = []
            for _ in range(10):
                start_time = time.time()
                with torch.no_grad():
                    _ = model(x)
                times.append(time.time() - start_time)
            
            avg_time = sum(times) / len(times)
            print(f"  平均时间: {avg_time:.4f}s")
            print(f"  标准差: {(sum((t - avg_time) ** 2 for t in times) / len(times)) ** 0.5:.4f}s")
            
        except Exception as e:
            print(f"  测试失败: {e}")


def test_memory_management(device_manager):
    
    print("\n" + "=" * 50)
    print("测试内存管理")
    print("=" * 50)
    
    if device_manager.device_type == "cuda":
        print("CUDA内存使用情况:")
        print(f"  已分配: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")
        print(f"  已缓存: {torch.cuda.memory_reserved() / 1024**2:.2f} MB")
        
        # 清理内存
        torch.cuda.empty_cache()
        print("  内存已清理")
        print(f"  清理后已分配: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")
        print(f"  清理后已缓存: {torch.cuda.memory_reserved() / 1024**2:.2f} MB")
    elif device_manager.device_type == "mps":
    else:


def test_cpu_gpu_switch():
    
    print("\n" + "=" * 50)
    print("测试CPU/GPU切换")
    print("=" * 50)
    
    # CPU模式
    print("\n1. CPU模式")
    cpu_device_manager = create_device_manager(device="cpu", auto_detect=False)
    cpu_model = SimpleModel()
    cpu_wrapped_model = wrap_model_for_gpu(cpu_model, cpu_device_manager)
    
    # GPU模式（如果可用）
    print("\n2. GPU模式")
    try:
        gpu_device_manager = create_device_manager(device="mps", auto_detect=False)
        gpu_model = SimpleModel()
        gpu_wrapped_model = wrap_model_for_gpu(gpu_model, gpu_device_manager)
        
        # 性能比较
        print("\n3. 性能比较")
        x = torch.randn(4, 768)
        
        # CPU性能
        import time
        cpu_times = []
        for _ in range(5):
            start = time.time()
            with torch.no_grad():
                _ = cpu_wrapped_model(x)
            cpu_times.append(time.time() - start)
        cpu_avg = sum(cpu_times) / len(cpu_times)
        
        # GPU性能
        gpu_times = []
        for _ in range(5):
            start = time.time()
            with torch.no_grad():
                _ = gpu_wrapped_model(x)
            gpu_times.append(time.time() - start)
        gpu_avg = sum(gpu_times) / len(gpu_times)
        
        print(f"CPU平均时间: {cpu_avg:.4f}s")
        print(f"GPU平均时间: {gpu_avg:.4f}s")
        print(f"加速比: {cpu_avg / gpu_avg:.2f}x")
        
    except Exception as e:
        print(f"GPU模式不可用: {e}")


def main():
    
    print("Started")
    
    try:
        # 测试设备管理器
        device_manager = test_device_manager()
        
        # 测试模型包装器
        model = test_model_wrapper(device_manager)
        
        # 测试性能基准
        test_performance_benchmark(model, device_manager)
        
        # 测试内存管理
        test_memory_management(device_manager)
        
        # 测试CPU/GPU切换
        test_cpu_gpu_switch()
        
        print("\n" + "=" * 50)
        print("Completed")
        print("=" * 50)
        
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
