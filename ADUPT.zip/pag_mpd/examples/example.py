import os
import sys
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from typing import Dict, List, Tuple

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from core.incomplete_multimodal_learning import IncompleteMultimodalLearning
from core.method_model_gpu import MethodModelGPU
from configs.config import get_config, validate_config
from configs.implementation_details import get_implementation_config


class MultimodalDataset(Dataset):
    
    def __init__(self, data_type: str = "complete", num_samples: int = 1000):
        """
        初始化数据集
        
        Args:
            data_type: "complete" 或 "incomplete"
            num_samples: 样本数量
        """
        self.data_type = data_type
        self.num_samples = num_samples
        self.modality_names = ["text", "image", "audio"]
        self.num_modalities = len(self.modality_names)
        
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        """
        获取数据样本
        
        返回格式：
        - x: 原始输入 {modality: x^(k)}
        - m: 存在掩码 (M,)
        - y: 标签
        """
        # 模拟原始输入
        x = {}
        
        # 文本模态 x^(1)
        x["text"] = torch.randint(0, 1000, (1, 40))  # 文本token序列 (B, L)
        
        # 图像模态 x^(2)  
        x["image"] = torch.randn(1, 3, 224, 224)  # 图像张量 (B, C, H, W)
        
        # 音频模态 x^(3)
        x["audio"] = torch.randn(1, 100, 128)  # 音频特征序列 (B, L, D)
        
        # 存在掩码 m ∈ {0,1}^M
        if self.data_type == "complete":
            # 完整数据：m = 1 (所有模态都存在)
            m = torch.ones(self.num_modalities, dtype=torch.long)
        else:
            # 不完整数据：m ≠ 1 (某些模态缺失)
            # 随机选择缺失模式
            missing_patterns = [
                [1, 0, 1],  # 缺失图像
                [0, 1, 1],  # 缺失文本
                [1, 1, 0],  # 缺失音频
                [0, 0, 1],  # 缺失文本和图像
                [0, 1, 0],  # 缺失文本和音频
                [1, 0, 0],  # 缺失图像和音频
            ]
            pattern_idx = idx % len(missing_patterns)
            m = torch.tensor(missing_patterns[pattern_idx], dtype=torch.long)
        
        # 标签
        y = torch.randint(0, 2, (1,))  # 保持tensor格式
        
        return {
            "x": x,
            "m": m,
            "y": y
        }


def demonstrate_preliminaries():
    print("=" * 60)
    print("论文Preliminaries部分演示")
    print("=" * 60)
    
    # 1. 问题设置和符号定义
    print("\n1. 问题设置和符号定义")
    print("-" * 30)
    
    # M个异构模态
    M = 3
    modality_names = ["text", "image", "audio"]
    print(f"M = {M} 个异构模态: {modality_names}")
    
    # 存在掩码 m ∈ {0,1}^M
    m = torch.tensor([1, 0, 1], dtype=torch.long)  # 示例：缺失图像
    print(f"存在掩码 m = {m.tolist()}")
    
    # P(m) = {k: m_k = 1} (存在的模态)
    P_m = [i for i in range(M) if m[i] == 1]
    print(f"P(m) = {P_m} (存在的模态索引)")
    
    # A(m) = {k: m_k = 0} (缺失的模态)
    A_m = [i for i in range(M) if m[i] == 0]
    print(f"A(m) = {A_m} (缺失的模态索引)")
    
    # 2. 骨干网络和标记化
    print("\n2. 骨干网络和标记化")
    print("-" * 30)
    
    # 获取配置
    config = get_config("multimodal_audio")
    
    # 创建基础IML模型
    iml_model = IncompleteMultimodalLearning(config)
    print("✓ 创建基础IML模型")
    print(f"  - 模态编码器: {list(iml_model.modality_encoders.keys())}")
    print(f"  - 隐藏维度: {iml_model.hidden_size}")
    print(f"  - 类别数量: {iml_model.num_classes}")
    
    # 3. 数据子集
    print("\n3. 数据子集")
    print("-" * 30)
    
    # 完整子集 D_c
    complete_dataset = MultimodalDataset("complete", num_samples=100)
    print(f"完整子集 D_c: {len(complete_dataset)} 个样本")
    
    # 不完整子集 D_s  
    incomplete_dataset = MultimodalDataset("incomplete", num_samples=900)
    print(f"不完整子集 D_s: {len(incomplete_dataset)} 个样本")
    print(f"|D_c| << |D_s|: {len(complete_dataset)} << {len(incomplete_dataset)}")
    
    # 4. 标记化演示
    print("\n4. 标记化演示")
    print("-" * 30)
    
    # 获取一个样本
    sample = incomplete_dataset[0]
    x = sample["x"]
    m = sample["m"]
    y = sample["y"]
    
    print(f"样本标签: {y}")
    print(f"存在掩码: {m.tolist()}")
    
    # 编码各模态
    modality_tokens = iml_model.encode_modalities(x, m)
    print("编码后的标记:")
    for modality, tokens in modality_tokens.items():
        print(f"  {modality}: {tokens.shape}")
    
    # 5. 融合和预测
    print("\n5. 融合和预测")
    print("-" * 30)
    
    # 前向传播
    logits = iml_model(x, m)
    print(f"预测logits: {logits.shape}")
    print(f"预测类别: {logits.argmax(dim=-1).item()}")
    
    # 任务损失
    task_loss = iml_model.compute_task_loss(logits, torch.tensor(y))
    print(f"任务损失: {task_loss.item():.4f}")
    
    # 6. 可学习参数
    print("\n6. 可学习参数")
    print("-" * 30)
    
    learnable_params = iml_model.get_learnable_parameters()
    total_params = sum(p.numel() for p in learnable_params)
    print(f"可学习参数数量: {total_params:,}")
    print("只有轻量级提示参数、小适配器和任务头是可学习的")
    print("所有编码器{f_k}和F保持冻结")


def demonstrate_method():
    """演示论文Method部分"""
    print("\n" + "=" * 60)
    print("论文Method部分演示")
    print("=" * 60)
    
    # 获取基础配置
    base_config = get_config("multimodal_audio")
    
    # 获取Implementation Details配置
    implementation_config = get_implementation_config("CMU-MOSEI")
    
    # 合并配置
    config = {**base_config, "implementation_details": implementation_config}
    
    # 创建集成GPU接口的最终模型
    model = MethodModelGPU(config, device=None, auto_detect_device=True)
    print("✓ 创建缺失感知蒸馏模型")
    
    # 显示参数效率统计
    model.print_parameter_efficiency()
    
    # 1. 教师T和推理网络I
    print("\n1. 教师T和推理网络I")
    print("-" * 30)
    print("教师T: 在D_c上训练")
    print("推理网络I: 在D_s∪D_c上训练")
    
    # 2. 两种提示族
    print("\n2. 两种提示族")
    print("-" * 30)
    print("模态级提示 P^mod(m): 缺失感知上下文")
    print("实例级双提示 P^sp, P^gn: 专业化和泛化")
    
    # 3. 分层蒸馏
    print("\n3. 分层蒸馏")
    print("-" * 30)
    print("特征级和预测级知识从T转移到I")
    
    # 4. 硬负样本对比
    print("\n4. 硬负样本对比")
    print("-" * 30)
    print("增强类别边界的判别性")
    
    # 5. 校准提示适应
    print("\n5. 校准提示适应")
    print("-" * 30)
    print("运行时单步校准适应")
    
    # 6. 训练演示
    print("\n6. 训练演示")
    print("-" * 30)
    
    # 创建数据加载器
    complete_loader = DataLoader(MultimodalDataset("complete", 50), batch_size=8, shuffle=True)
    incomplete_loader = DataLoader(MultimodalDataset("incomplete", 50), batch_size=8, shuffle=True)
    
    # 阶段1：教师训练
    print("阶段1：教师训练")
    model.set_teacher_trained(False)
    model.set_inference_trained(False)
    
    for i, batch in enumerate(complete_loader):
        if i >= 2:  # 只演示几个批次
            break
        
        # 提取数据 - 处理批次数据
        x_batch = {k: v for k, v in batch["x"].items()}
        m_batch = batch["m"][0]  # 取第一个样本的掩码
        y_batch = batch["y"][0]  # 取第一个样本的标签
        
        # 前向传播
        outputs = model(x_batch, m_batch, y_batch)
        
        print(f"  批次 {i+1}: 损失 = {outputs.get('loss', 0):.4f}")
    
    # 设置教师训练完成
    model.set_teacher_trained(True)
    print("✓ 教师训练完成")
    
    # 阶段2：推理训练
    print("\n阶段2：推理训练")
    model.set_inference_trained(False)
    
    for i, batch in enumerate(incomplete_loader):
        if i >= 2:  # 只演示几个批次
            break
        
        # 提取数据 - 处理批次数据
        x_batch = {k: v for k, v in batch["x"].items()}
        m_batch = batch["m"][0]  # 取第一个样本的掩码
        y_batch = batch["y"][0]  # 取第一个样本的标签
        
        # 前向传播
        outputs = model(x_batch, m_batch, y_batch)
        
        print(f"  批次 {i+1}: 总损失 = {outputs.get('L_total', 0):.4f}")
        print(f"    任务损失 L_cls: {outputs.get('L_cls', 0):.4f}")
        print(f"    掩码重构损失 L_abs: {outputs.get('L_abs', 0):.4f}")
        print(f"    特征蒸馏损失 L_feat: {outputs.get('L_feat', 0):.4f}")
        print(f"    预测蒸馏损失 L_pred: {outputs.get('L_pred', 0):.4f}")
        print(f"    硬负样本对比损失 L_hno: {outputs.get('L_hno', 0):.4f}")
    
    # 设置推理训练完成
    model.set_inference_trained(True)
    print("✓ 推理训练完成")
    
    # 阶段3：推理模式
    print("\n阶段3：推理模式")
    
    # 测试样本
    test_sample = incomplete_dataset[0]
    x_test = test_sample["x"]
    m_test = test_sample["m"]
    
    # 推理
    with torch.no_grad():
        outputs = model(x_test, m_test)
    
    print(f"测试样本预测: {outputs['logits'].argmax(dim=-1).item()}")
    print(f"预测概率: {torch.softmax(outputs['logits'], dim=-1).tolist()}")


def main():
    """主函数"""
    print("严格按照论文Preliminaries和Method部分的示例")
    print("=" * 60)
    
    # 验证配置
    config = get_config("multimodal_audio")
    if validate_config(config):
        print("✓ 配置验证通过")
    else:
        print("✗ 配置验证失败")
        return
    
    # 演示Preliminaries部分
    demonstrate_preliminaries()
    
    # 演示Method部分
    demonstrate_method()
    
    print("\n" + "=" * 60)
    print("演示完成！")
    print("=" * 60)


if __name__ == "__main__":
    main()
