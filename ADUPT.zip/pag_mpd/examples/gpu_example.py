"""
GPU示例 - GPU接口的使用
"""

import os
import sys
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np
from PIL import Image

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from core.method_model_gpu import MethodModelGPU
from core.gpu_interface import create_device_manager, wrap_model_for_gpu, wrap_dataloader_for_gpu
from configs.config import get_config, validate_config
from configs.implementation_details import get_implementation_config


class GPUDataset(Dataset):
    """
    GPU数据集 - 支持GPU加速的数据集
    """
    
    def __init__(self, num_samples: int = 100, device_manager=None):
        self.num_samples = num_samples
        self.device_manager = device_manager
        
        # 生成模拟数据
        self.data = []
        for i in range(num_samples):
            sample = {
                "text": f"Sample text {i}",
                "image": np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8),
                "audio": np.random.randn(100, 74).astype(np.float32),
                "missing_mask": torch.tensor([1, 1, 1]),  # 所有模态都存在
                "label": torch.randint(0, 2, (1,)).item()
            }
            self.data.append(sample)
    
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        sample = self.data[idx]
        
        # 如果指定了设备管理器，将数据移动到指定设备
        if self.device_manager is not None:
            sample = self.device_manager.to_device(sample)
        
        return sample


def demonstrate_gpu_functionality():
    
    print("=" * 60)
    print("GPU功能演示")
    print("=" * 60)
    
    # 1. 创建设备管理器
    print("\n1. 创建设备管理器")
    print("-" * 30)
    device_manager = create_device_manager(device=None, auto_detect=True)
    device_manager.print_device_info()
    
    # 2. 创建模型
    print("\n2. 创建模型")
    print("-" * 30)
    
    # 获取配置
    base_config = get_config("cmu-mosi")
    implementation_config = get_implementation_config("CMU-MOSEI")
    config = {**base_config, "implementation_details": implementation_config}
    
    # 创建GPU模型
    model = MethodModelGPU(config, device=None, auto_detect_device=True)
    print("Completed")
    
    # 3. 显示设备信息
    print("\n3. 设备信息")
    print("-" * 30)
    device_info = model.get_device_info()
    for key, value in device_info.items():
        print(f"{key}: {value}")
    
    # 4. 性能基准测试
    print("\n4. 性能基准测试")
    print("-" * 30)
    
    # 测试不同输入形状的性能
    input_shapes = [
        (3, 224, 224),  # 图像
        (128,),         # 文本
        (100, 74)       # 音频
    ]
    
    for shape in input_shapes:
        print(f"\n测试输入形状: {shape}")
        try:
            performance = model.benchmark_performance(shape, num_runs=5)
            print(f"  平均时间: {performance['mean_time']:.4f}s")
            print(f"  标准差: {performance['std_time']:.4f}s")
            print(f"  最小时间: {performance['min_time']:.4f}s")
            print(f"  最大时间: {performance['max_time']:.4f}s")
        except Exception as e:
            print(f"  测试失败: {e}")
    
    # 5. 最优批次大小测试
    print("\n5. 最优批次大小测试")
    print("-" * 30)
    
    try:
        optimal_batch_size = model.get_optimal_batch_size((3, 224, 224), max_batch_size=32)
        print(f"最优批次大小: {optimal_batch_size}")
    except Exception as e:
        print(f"批次大小测试失败: {e}")
    
    # 6. 创建数据集和数据加载器
    print("\n6. 创建数据集和数据加载器")
    print("-" * 30)
    
    dataset = GPUDataset(num_samples=50, device_manager=device_manager)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True)
    
    # 包装数据加载器以支持GPU
    gpu_dataloader = wrap_dataloader_for_gpu(dataloader, device_manager)
    
    print(f"数据集大小: {len(dataset)}")
    print(f"数据加载器批次大小: {dataloader.batch_size}")
    
    # 7. 模型推理测试
    print("\n7. 模型推理测试")
    print("-" * 30)
    
    model.eval()
    with torch.no_grad():
        for i, batch in enumerate(gpu_dataloader):
            if i >= 3:  # 只测试前3个批次
                break
            
            print(f"  批次 {i+1}:")
            
            # 提取数据
            x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
            m_batch = batch["missing_mask"][0]  # 取第一个样本的掩码
            y_batch = batch["label"][0]  # 取第一个样本的标签
            
            try:
                # 前向传播
                outputs = model(x_batch, m_batch, y_batch)
                
                print(f"    输出键: {list(outputs.keys())}")
                if "logits" in outputs:
                    print(f"    logits形状: {outputs['logits'].shape}")
                if "probs" in outputs:
                    print(f"    probs形状: {outputs['probs'].shape}")
                
            except Exception as e:
                print(f"    推理失败: {e}")
    
    # 8. 内存管理
    print("\n8. 内存管理")
    print("-" * 30)
    
    # 清理GPU内存
    model.clear_memory()
    print(" GPU内存已清理")
    
    # 显示内存使用情况
    if device_manager.device_type == "cuda":
        print(f"GPU内存已分配: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")
        print(f"GPU内存已缓存: {torch.cuda.memory_reserved() / 1024**2:.2f} MB")
    
    print("Completed")


def demonstrate_cpu_gpu_switch():
    
    print("\n" + "=" * 60)
    print("CPU/GPU切换演示")
    print("=" * 60)
    
    # 获取配置
    base_config = get_config("cmu-mosi")
    implementation_config = get_implementation_config("CMU-MOSEI")
    config = {**base_config, "implementation_details": implementation_config}
    
    # 1. CPU模式
    print("\n1. CPU模式")
    print("-" * 30)
    cpu_model = MethodModelGPU(config, device="cpu", auto_detect_device=False)
    print("Completed")
    
    # 2. GPU模式（如果可用）
    print("\n2. GPU模式")
    print("-" * 30)
    try:
        gpu_model = MethodModelGPU(config, device="cuda", auto_detect_device=False)
        print("Completed")
        
        # 比较性能
        print("\n3. 性能比较")
        print("-" * 30)
        
        input_shape = (3, 224, 224)
        
        # CPU性能
        print("CPU性能测试...")
        cpu_performance = cpu_model.benchmark_performance(input_shape, num_runs=3)
        print(f"CPU平均时间: {cpu_performance['mean_time']:.4f}s")
        
        # GPU性能
        print("GPU性能测试...")
        gpu_performance = gpu_model.benchmark_performance(input_shape, num_runs=3)
        print(f"GPU平均时间: {gpu_performance['mean_time']:.4f}s")
        
        # 计算加速比
        speedup = cpu_performance['mean_time'] / gpu_performance['mean_time']
        print(f"GPU加速比: {speedup:.2f}x")
        
    except Exception as e:
        print(f"GPU模式不可用: {e}")
        print("继续使用CPU模式")


def demonstrate_multi_gpu():
    
    print("\n" + "=" * 60)
    print("多GPU支持演示")
    print("=" * 60)
    
    # 检查可用GPU数量
    if torch.cuda.is_available():
        gpu_count = torch.cuda.device_count()
        print(f"检测到 {gpu_count} 个GPU")
        
        for i in range(gpu_count):
            print(f"  GPU {i}: {torch.cuda.get_device_name(i)}")
            print(f"    内存: {torch.cuda.get_device_properties(i).total_memory / 1024**3:.1f} GB")
        
        # 演示多GPU使用
        if gpu_count > 1:
            print(f"\n使用GPU 0进行演示")
            device_manager = create_device_manager(device="cuda:0", auto_detect=False)
        else:
            print(f"\n只有一个GPU，使用GPU 0")
            device_manager = create_device_manager(device="cuda:0", auto_detect=False)
    else:
        print("没有检测到CUDA GPU")
        return


if __name__ == "__main__":
    print("Started")
    
    try:
        # 基本GPU功能演示
        demonstrate_gpu_functionality()
        
        # CPU/GPU切换演示
        demonstrate_cpu_gpu_switch()
        
        # 多GPU支持演示
        demonstrate_multi_gpu()
        
        print("\n" + "=" * 60)
        print("Completed")
        print("=" * 60)
        
    except Exception as e:
        print(f"演示过程中出现错误: {e}")
        import traceback
        traceback.print_exc()

