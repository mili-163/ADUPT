import os
import sys
import torch
import logging
from torch.utils.data import DataLoader, random_split
from typing import Dict, Any

# 添加项目根目录到路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pag_mpd.core.training_pipeline import TrainingPipeline, InferencePipeline
from pag_mpd.core.absence_aware_distillation_model import AbsenceAwareDistillationModel
from pag_mpd.configs.absence_aware_distillation_config import get_config
from pag_mpd.datasets.hatememes_dataset import HatefulMemesDataset
from pag_mpd.datamodules.hatememes_datamodule import HatefulMemesDataModule


def setup_logging():
    """设置日志"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('training.log'),
            logging.StreamHandler()
        ]
    )


def create_mock_dataset():
    """创建模拟数据集用于测试"""
    # 这里应该根据实际数据集创建
    # 为了演示，我们创建一个简单的模拟数据集
    class MockDataset:
        def __init__(self, size=1000):
            self.size = size
        
        def __len__(self):
            return self.size
        
        def __getitem__(self, idx):
            # 模拟数据
            batch = {
                "text_ids": torch.randint(0, 1000, (40,)),
                "text_masks": torch.ones(40),
                "image": (torch.randn(3, 224, 224),),
                "missing_type": torch.randint(0, 3, (1,)).item(),  # 0: 完整, 1: 缺失文本, 2: 缺失图像
                "labels": torch.randint(0, 2, (1,)).item()
            }
            return batch
    
    return MockDataset()


def main():
    """主函数"""
    # 设置日志
    setup_logging()
    logger = logging.getLogger(__name__)
    
    # 获取配置
    config = get_config("hatememes")
    logger.info(f"使用配置: {config}")
    
    # 创建模拟数据集
    logger.info("创建数据集...")
    full_dataset = create_mock_dataset()
    
    # 分割数据集
    train_size = int(0.8 * len(full_dataset))
    val_size = int(0.1 * len(full_dataset))
    test_size = len(full_dataset) - train_size - val_size
    
    train_dataset, val_dataset, test_dataset = random_split(
        full_dataset, [train_size, val_size, test_size]
    )
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset, 
        batch_size=config["batch_size"], 
        shuffle=True,
        num_workers=config["num_workers"]
    )
    val_loader = DataLoader(
        val_dataset, 
        batch_size=config["batch_size"], 
        shuffle=False,
        num_workers=config["num_workers"]
    )
    test_loader = DataLoader(
        test_dataset, 
        batch_size=config["batch_size"], 
        shuffle=False,
        num_workers=config["num_workers"]
    )
    
    # 创建训练管道
    logger.info("初始化训练管道...")
    training_pipeline = TrainingPipeline(config)
    
    try:
        # 阶段1：教师训练
        logger.info("=" * 50)
        logger.info("开始教师训练阶段")
        logger.info("=" * 50)
        
        teacher_metrics = training_pipeline.train_teacher(
            train_loader=train_loader,
            val_loader=val_loader,
            num_epochs=config["num_epochs_teacher"]
        )
        
        logger.info(f"教师训练完成，最终验证准确率: {teacher_metrics['val_acc'][-1]:.4f}")
        
        # 阶段2：推理训练
        logger.info("=" * 50)
        logger.info("开始推理训练阶段")
        logger.info("=" * 50)
        
        # 创建不完整数据加载器（模拟缺失模态）
        incomplete_loader = train_loader  # 在实际应用中，这里应该是真正的不完整数据
        
        inference_metrics = training_pipeline.train_inference(
            complete_loader=train_loader,
            incomplete_loader=incomplete_loader,
            val_loader=val_loader,
            num_epochs=config["num_epochs_inference"]
        )
        
        logger.info(f"推理训练完成，最终验证准确率: {inference_metrics['val_acc'][-1]:.4f}")
        
        # 阶段3：评估
        logger.info("=" * 50)
        logger.info("开始模型评估")
        logger.info("=" * 50)
        
        # 不使用CPA的评估
        metrics_without_cpa = training_pipeline.evaluate(test_loader, use_cpa=False)
        logger.info(f"不使用CPA的测试准确率: {metrics_without_cpa['accuracy']:.4f}")
        
        # 使用CPA的评估
        metrics_with_cpa = training_pipeline.evaluate(test_loader, use_cpa=True)
        logger.info(f"使用CPA的测试准确率: {metrics_with_cpa['accuracy']:.4f}")
        
        # 保存最终模型
        logger.info("保存最终模型...")
        torch.save({
            'model_state_dict': training_pipeline.model.state_dict(),
            'config': config,
            'teacher_metrics': teacher_metrics,
            'inference_metrics': inference_metrics,
            'test_metrics': metrics_with_cpa
        }, 'final_model.pt')
        
        logger.info("训练完成！")
        
    except Exception as e:
        logger.error(f"训练过程中出现错误: {e}")
        raise


def demo_inference():
    """演示推理过程"""
    logger = logging.getLogger(__name__)
    
    # 加载配置
    config = get_config("hatememes")
    
    # 创建模型
    model = AbsenceAwareDistillationModel(config)
    
    # 创建推理管道
    inference_pipeline = InferencePipeline(model, config)
    
    # 创建模拟批次
    batch = {
        "text_ids": torch.randint(0, 1000, (1, 40)),
        "text_masks": torch.ones(1, 40),
        "image": (torch.randn(1, 3, 224, 224),),
        "missing_type": torch.tensor([1]),  # 缺失文本
        "labels": torch.tensor([0])
    }
    
    # 推理
    logger.info("演示推理过程...")
    outputs = inference_pipeline.infer_with_cpa(batch)
    
    logger.info(f"推理结果: {outputs}")
    logger.info(f"预测类别: {outputs['logits'].argmax(dim=-1)}")


if __name__ == "__main__":
    # 运行训练
    main()
    
    # 演示推理
    print("\n" + "=" * 50)
    print("演示推理过程")
    print("=" * 50)
    demo_inference()
