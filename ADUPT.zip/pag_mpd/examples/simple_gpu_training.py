"""
GPU训练脚本
"""

import os
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import time

# 添加项目根目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from core.gpu_interface import create_device_manager, wrap_model_for_gpu, wrap_dataloader_for_gpu


class SimpleMultimodalModel(nn.Module):
    
    def __init__(self, input_sizes, hidden_size=768, num_classes=2):
        super().__init__()
        self.input_sizes = input_sizes
        self.hidden_size = hidden_size
        self.num_classes = num_classes
        
        # 模态编码器
        self.text_encoder = nn.Linear(input_sizes["text"], hidden_size)
        self.image_encoder = nn.Linear(input_sizes["image"], hidden_size)
        self.audio_encoder = nn.Linear(input_sizes["audio"], hidden_size)
        
        # 融合层
        self.fusion = nn.Sequential(
            nn.Linear(hidden_size * 3, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size, hidden_size)
        )
        
        # 分类器
        self.classifier = nn.Linear(hidden_size, num_classes)
        
    def forward(self, x, missing_mask):
        """
        前向传播
        
        Args:
            x: 输入数据 {"text": ..., "image": ..., "audio": ...}
            missing_mask: 缺失掩码 (batch_size, 3)
        """
        batch_size = missing_mask.shape[0]
        
        # 编码各模态
        text_features = self.text_encoder(x["text"])  # (batch_size, hidden_size)
        image_features = self.image_encoder(x["image"])  # (batch_size, hidden_size)
        audio_features = self.audio_encoder(x["audio"])  # (batch_size, hidden_size)
        
        # 应用缺失掩码
        text_features = text_features * missing_mask[:, 0:1]  # 广播到hidden_size
        image_features = image_features * missing_mask[:, 1:2]
        audio_features = audio_features * missing_mask[:, 2:3]
        
        # 融合特征
        combined_features = torch.cat([text_features, image_features, audio_features], dim=1)
        fused_features = self.fusion(combined_features)
        
        # 分类
        logits = self.classifier(fused_features)
        
        return {
            "logits": logits,
            "features": fused_features
        }


class SimpleDataset(Dataset):
    
    
    def __init__(self, num_samples=1000, missing_rate=0.3):
        self.num_samples = num_samples
        self.missing_rate = missing_rate
        
        # 生成模拟数据
        self.data = []
        for i in range(num_samples):
            # 随机生成缺失掩码
            missing_mask = torch.rand(3) > missing_rate
            
            sample = {
                "text": torch.randn(40),  # 文本特征
                "image": torch.randn(224 * 224 * 3),  # 图像特征
                "audio": torch.randn(100 * 74),  # 音频特征
                "missing_mask": missing_mask.float(),
                "label": torch.randint(0, 2, (1,)).item()
            }
            self.data.append(sample)
    
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        return self.data[idx]


def train_model(model, train_loader, val_loader, device_manager, num_epochs=10):
    
    # 包装模型以支持GPU
    wrapped_model = wrap_model_for_gpu(model, device_manager)
    
    # 创建优化器和损失函数
    optimizer = optim.Adam(wrapped_model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()
    
    print("Training started")
    
    for epoch in range(num_epochs):
        # 训练阶段
        wrapped_model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0
        
        for batch_idx, batch in enumerate(train_loader):
            # 移动数据到GPU
            x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
            m_batch = batch["missing_mask"]
            y_batch = batch["label"]
            
            # 移动数据到设备
            x_batch = device_manager.to_device(x_batch)
            m_batch = device_manager.to_device(m_batch)
            y_batch = device_manager.to_device(y_batch)
            
            # 前向传播
            optimizer.zero_grad()
            outputs = wrapped_model(x_batch, m_batch)
            logits = outputs["logits"]
            
            # 计算损失
            loss = criterion(logits, y_batch)
            
            # 反向传播
            loss.backward()
            optimizer.step()
            
            # 统计
            train_loss += loss.item()
            predicted = logits.argmax(dim=-1)
            train_total += y_batch.size(0)
            train_correct += (predicted == y_batch).sum().item()
            
            if batch_idx % 10 == 0:
                print(f"  Epoch {epoch+1}, Batch {batch_idx}, Loss: {loss.item():.4f}")
        
        # 验证阶段
        wrapped_model.eval()
        val_correct = 0
        val_total = 0
        
        with torch.no_grad():
            for batch in val_loader:
                x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
                m_batch = batch["missing_mask"]
                y_batch = batch["label"]
                
                # 移动数据到设备
                x_batch = device_manager.to_device(x_batch)
                m_batch = device_manager.to_device(m_batch)
                y_batch = device_manager.to_device(y_batch)
                
                # 前向传播
                outputs = wrapped_model(x_batch, m_batch)
                logits = outputs["logits"]
                
                # 统计
                predicted = logits.argmax(dim=-1)
                val_total += y_batch.size(0)
                val_correct += (predicted == y_batch).sum().item()
        
        # 计算指标
        train_accuracy = train_correct / train_total
        val_accuracy = val_correct / val_total
        avg_train_loss = train_loss / len(train_loader)
        
        print(f"Epoch {epoch+1}/{num_epochs}:")
        print(f"  Train Loss: {avg_train_loss:.4f}, Train Acc: {train_accuracy:.4f}")
        print(f"  Val Acc: {val_accuracy:.4f}")
        print("-" * 50)
    
    return wrapped_model


def test_model(model, test_loader, device_manager):
    
    print("Started")
    
    model.eval()
    
    # 不同缺失模式的测试
    missing_patterns = {
        "complete": torch.tensor([1.0, 1.0, 1.0]),
        "missing_text": torch.tensor([0.0, 1.0, 1.0]),
        "missing_image": torch.tensor([1.0, 0.0, 1.0]),
        "missing_audio": torch.tensor([1.0, 1.0, 0.0]),
        "missing_text_image": torch.tensor([0.0, 0.0, 1.0]),
        "missing_text_audio": torch.tensor([0.0, 1.0, 0.0]),
        "missing_image_audio": torch.tensor([1.0, 0.0, 0.0])
    }
    
    results = {}
    
    for pattern_name, pattern_mask in missing_patterns.items():
        print(f"\n测试缺失模式: {pattern_name}")
        
        correct = 0
        total = 0
        
        with torch.no_grad():
            for batch in test_loader:
                x_batch = {k: v for k, v in batch.items() if k in ["text", "image", "audio"]}
                y_batch = batch["label"]
                
                # 移动数据到设备
                x_batch = device_manager.to_device(x_batch)
                y_batch = device_manager.to_device(y_batch)
                
                # 使用指定的缺失模式
                m_batch = pattern_mask.unsqueeze(0).expand(y_batch.size(0), -1)
                m_batch = device_manager.to_device(m_batch)
                
                # 前向传播
                outputs = model(x_batch, m_batch)
                logits = outputs["logits"]
                
                # 计算准确率
                predicted = logits.argmax(dim=-1)
                total += y_batch.size(0)
                correct += (predicted == y_batch).sum().item()
        
        accuracy = correct / total if total > 0 else 0
        results[pattern_name] = accuracy
        print(f"  {pattern_name} 准确率: {accuracy:.4f}")
    
    return results


def main():
    
    print("=" * 60)
    print("简化GPU训练脚本")
    print("=" * 60)
    
    # 1. 创建设备管理器
    print("\n1. 创建设备管理器")
    print("-" * 30)
    device_manager = create_device_manager(device=None, auto_detect=True)
    device_manager.print_device_info()
    
    # 2. 创建数据集
    print("\n2. 创建数据集")
    print("-" * 30)
    train_dataset = SimpleDataset(num_samples=800, missing_rate=0.3)
    val_dataset = SimpleDataset(num_samples=100, missing_rate=0.3)
    test_dataset = SimpleDataset(num_samples=100, missing_rate=0.3)
    
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    # 包装数据加载器以支持GPU
    train_loader = wrap_dataloader_for_gpu(train_loader, device_manager)
    val_loader = wrap_dataloader_for_gpu(val_loader, device_manager)
    test_loader = wrap_dataloader_for_gpu(test_loader, device_manager)
    
    print(f"训练集大小: {len(train_dataset)}")
    print(f"验证集大小: {len(val_dataset)}")
    print(f"测试集大小: {len(test_dataset)}")
    
    # 3. 创建模型
    print("\n3. 创建模型")
    print("-" * 30)
    input_sizes = {
        "text": 40,
        "image": 224 * 224 * 3,
        "audio": 100 * 74
    }
    
    model = SimpleMultimodalModel(input_sizes, hidden_size=768, num_classes=2)
    print(f"模型参数数量: {sum(p.numel() for p in model.parameters()):,}")
    print(f"可训练参数数量: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    # 4. 训练模型
    print("\n4. 训练模型")
    print("-" * 30)
    trained_model = train_model(model, train_loader, val_loader, device_manager, num_epochs=10)
    
    # 5. 测试模型
    print("\n5. 测试模型")
    print("-" * 30)
    test_results = test_model(trained_model, test_loader, device_manager)
    
    # 6. 性能测试
    print("\n6. 性能测试")
    print("-" * 30)
    
    # 测试不同批次大小的性能
    batch_sizes = [1, 4, 8, 16, 32]
    
    for batch_size in batch_sizes:
        print(f"\n测试批次大小: {batch_size}")
        try:
            # 创建测试数据
            test_data = {
                "text": torch.randn(batch_size, 40),
                "image": torch.randn(batch_size, 224 * 224 * 3),
                "audio": torch.randn(batch_size, 100 * 74)
            }
            test_mask = torch.ones(batch_size, 3)
            
            # 移动数据到设备
            test_data = device_manager.to_device(test_data)
            test_mask = device_manager.to_device(test_mask)
            
            # 预热
            with torch.no_grad():
                for _ in range(3):
                    _ = trained_model(test_data, test_mask)
            
            # 基准测试
            times = []
            for _ in range(10):
                start_time = time.time()
                with torch.no_grad():
                    _ = trained_model(test_data, test_mask)
                times.append(time.time() - start_time)
            
            avg_time = sum(times) / len(times)
            print(f"  平均时间: {avg_time:.4f}s")
            print(f"  吞吐量: {batch_size / avg_time:.2f} samples/s")
            
        except Exception as e:
            print(f"  测试失败: {e}")
    
    # 7. 内存使用情况
    print("\n7. 内存使用情况")
    print("-" * 30)
    device_info = device_manager.get_device_info()
    for key, value in device_info.items():
        print(f"{key}: {value}")
    
    print("\n" + "=" * 60)
    print("Completed")
    print("=" * 60)
    
    # 保存结果
    results_summary = {
        "test_results": test_results,
        "device_info": device_info,
        "model_parameters": sum(p.numel() for p in model.parameters()),
        "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad)
    }
    
    print("\n结果摘要:")
    for key, value in results_summary.items():
        if isinstance(value, dict):
            print(f"{key}:")
            for k, v in value.items():
                print(f"  {k}: {v}")
        else:
            print(f"{key}: {value}")


if __name__ == "__main__":
    main()
