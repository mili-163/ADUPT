import torch
import numpy as np
from .base_dataset import BaseDataset


class CMUMOSEIDataset(BaseDataset):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.audio_length = kwargs.get('audio_length', 100)
        self.audio_feature_dim = kwargs.get('audio_feature_dim', 74)
    
    def __getitem__(self, index):
        sample = super().__getitem__(index)
        
        # 添加音频数据
        if 'audio' not in sample:
            # 生成模拟音频特征
            audio_features = np.random.randn(self.audio_length, self.audio_feature_dim).astype(np.float32)
            sample['audio'] = torch.from_numpy(audio_features)
        
        return sample
