from .mmimdb_datamodule import MMIMDBDataModule
from .hatememes_datamodule import HateMemesDataModule
from .food101_datamodule import FOOD101DataModule
from .cmu_mosei_datamodule import CMUMOSEIDataModule

_datamodules = {
    "mmimdb": MMIMDBDataModule,
    "hatememes": HateMemesDataModule,
    "food101": FOOD101DataModule,
    "cmu-mosei": CMUMOSEIDataModule,
}
