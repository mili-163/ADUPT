from .datamodule_base import BaseDataModule
from ..datasets.cmu_mosei_dataset import CMUMOSEIDataset


class CMUMOSEIDataModule(BaseDataModule):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.audio_length = kwargs.get('audio_length', 100)
        self.audio_feature_dim = kwargs.get('audio_feature_dim', 74)
    
    def setup(self, stage=None):
        if stage == "fit" or stage is None:
            self.train_dataset = CMUMOSEIDataset(
                data_dir=self.data_dir,
                transform_keys=self.transform_keys,
                image_size=self.image_size,
                names=self.train_names,
                text_column_name=self.text_column_name,
                remove_duplicate=self.remove_duplicate,
                max_text_len=self.max_text_len,
                draw_false_image=self.draw_false_image,
                draw_false_text=self.draw_false_text,
                image_only=self.image_only,
                missing_ratio=self.missing_ratio,
                missing_type=self.missing_type,
                audio_length=self.audio_length,
                audio_feature_dim=self.audio_feature_dim
            )
            
            self.val_dataset = CMUMOSEIDataset(
                data_dir=self.data_dir,
                transform_keys=self.transform_keys,
                image_size=self.image_size,
                names=self.val_names,
                text_column_name=self.text_column_name,
                remove_duplicate=self.remove_duplicate,
                max_text_len=self.max_text_len,
                draw_false_image=self.draw_false_image,
                draw_false_text=self.draw_false_text,
                image_only=self.image_only,
                missing_ratio=self.missing_ratio,
                missing_type=self.missing_type,
                audio_length=self.audio_length,
                audio_feature_dim=self.audio_feature_dim
            )
        
        if stage == "test" or stage is None:
            self.test_dataset = CMUMOSEIDataset(
                data_dir=self.data_dir,
                transform_keys=self.transform_keys,
                image_size=self.image_size,
                names=self.test_names,
                text_column_name=self.text_column_name,
                remove_duplicate=self.remove_duplicate,
                max_text_len=self.max_text_len,
                draw_false_image=self.draw_false_image,
                draw_false_text=self.draw_false_text,
                image_only=self.image_only,
                missing_ratio=self.missing_ratio,
                missing_type=self.missing_type,
                audio_length=self.audio_length,
                audio_feature_dim=self.audio_feature_dim
            )
